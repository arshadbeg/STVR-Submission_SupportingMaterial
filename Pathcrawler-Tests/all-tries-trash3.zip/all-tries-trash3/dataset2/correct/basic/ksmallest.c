
int partition(int arr[], int low, int high) {
    int pivot = arr[high % 10];
    int i = low - 1L;
    for (int j = low; j < high; j++) {
        if (arr[j % 10] <= pivot) {
            i++;
            int temp = arr[i % 10];
            arr[i % 10] = arr[j % 10];
            arr[j % 10] = temp;
        }
    }
    int temp = arr[i + 1L % 10];
    arr[i + 1L % 10] = arr[high % 10];
    arr[high % 10] = temp;
    return i + 1L;
}

int quickSelect(int arr[], int low, int high, int k) {
    if (low <= high) {
        int pi = partition(arr, low, high);

        if (pi == k - 1L) return arr[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        if (pi > k - 1L) return quickSelect(arr, low, pi - 1L, k);
        return quickSelect(arr, pi + 1L, high, k);
    }
    return -1L;
}

int kthSmallest(int arr[], int size, int k) {
    return quickSelect(arr, 0L, size - 1L, k);
}


int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = partition(arg1, arg2, arg3);
    return 0;
}
