:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(n(2), seq, [212, 213, n(6), n(16)]).
ast_node(fun(203), func, [main, 0, 0, 1, 240]).
ast_node(203, assign, [mode, e(+(p(i(si(4))), arr, mod(i(si(8)), c(0, i(si(8))), cast(i(si(8)), c(10, i(si(4)))))), c(0, i(si(4))))]).
ast_node(241, assign, [arg1, cast(i(si(4)), c(1, i(si(8))))]).
ast_node(204, assign, [i, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(201, seq, [202, 203, 204, n(1), 238]).
ast_node(207, cond, [inf, i, size]).
ast_node(216, cond, [inf, j, size]).
ast_node(229, cond, [sup, count, maxCount]).
ast_node(225, assign, [count, +(i(si(4)), count, c(1, i(si(4))))]).
ast_node(202, assign, [maxCount, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(212, assign, [count, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(243, rescall, [findMode, '__tmp_lin_0', cast(p(i(si(4))), arg1), arg2]).
ast_node(221, cond, [egal, e(+(p(i(si(4))), arr, mod(i(si(4)), j, c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(233, assign, [maxCount, count]).
ast_node(213, assign, [j, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(244, assign, [result, '__tmp_lin_0']).
ast_node(fun(193), func, [findMode, 2, 0, 1, 201]).
ast_node(242, assign, [arg2, cast(i(si(4)), c(2, i(si(8))))]).
ast_node(236, assign, [i, +(i(si(4)), i, c(1, i(si(4))))]).
ast_node(n(17), seq, [233, 234]).
ast_node(227, assign, [j, +(i(si(4)), j, c(1, i(si(4))))]).
ast_node(234, assign, [mode, e(+(p(i(si(4))), arr, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(n(16), ite, [229, n(17), empty]).
ast_node(n(6), for, [216, n(11), 227]).
ast_node(n(11), ite, [221, 225, empty]).
ast_node(n(1), for, [207, n(2), 236]).
ast_node(245, setres, [c(0, i(si(4)))]).
ast_node(fun(184), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(240, seq, [241, 242, 243, 244, 245]).
ast_node(238, setres, [mode]).
ast_supernode(240, fun(203), 0, fun(203)).
ast_supernode(201, fun(193), 0, fun(193)).
ast_supernode(241, 240, 0, fun(203)).
ast_supernode(242, 240, 1, fun(203)).
ast_supernode(243, 240, 2, fun(203)).
ast_supernode(244, 240, 3, fun(203)).
ast_supernode(245, 240, 4, fun(203)).
ast_supernode(202, 201, 0, fun(193)).
ast_supernode(203, 201, 1, fun(193)).
ast_supernode(n(1), 201, 3, fun(193)).
ast_supernode(204, 201, 2, fun(193)).
ast_supernode(n(2), n(1), body, fun(193)).
ast_supernode(n(6), n(2), 2, fun(193)).
ast_supernode(213, n(2), 1, fun(193)).
ast_supernode(227, n(6), action, fun(193)).
ast_supernode(n(11), n(6), body, fun(193)).
ast_supernode(225, n(11), then, fun(193)).
ast_supernode(236, n(1), action, fun(193)).
ast_supernode(n(16), n(2), 3, fun(193)).
ast_supernode(n(17), n(16), then, fun(193)).
ast_supernode(212, n(2), 0, fun(193)).
ast_supernode(238, 201, 4, fun(193)).
ast_supernode(233, n(17), 0, fun(193)).
ast_supernode(234, n(17), 1, fun(193)).
ast_supernode(216, n(6), cond, fun(193)).
ast_supernode(221, n(11), cond, fun(193)).
ast_supernode(207, n(1), cond, fun(193)).
ast_supernode(229, n(16), cond, fun(193)).
topleveldec(216, n(6), [216]).
topleveldec(221, n(11), [221]).
topleveldec(207, n(1), [207]).
topleveldec(229, n(16), [229]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(216, 1, 0, n(6)).
immediate_dom_branch_loop_iter(207, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(16), 'mode.c', 11, 0).
stmt_location(n(11), 'mode.c', 7, 0).
stmt_location(n(1), 'mode.c', 4, 0).
stmt_location(n(6), 'mode.c', 6, 0).
stmt_location(n(2), 'mode.c', 5, 0).
stmt_location(fun(203), 'mode.c', 21, 0).
stmt_location(241, 'mode.c', 22, 0).
stmt_location(238, 'mode.c', 17, 0).
stmt_location(201, 'mode.c', 2, 0).
stmt_location(207, 'mode.c', 4, 0).
stmt_location(216, 'mode.c', 6, 0).
stmt_location(229, 'mode.c', 11, 0).
stmt_location(225, 'mode.c', 8, 0).
stmt_location(202, 'mode.c', 2, 1).
stmt_location(203, 'mode.c', 2, 2).
stmt_location(212, 'mode.c', 5, 0).
stmt_location(243, 'mode.c', 24, 0).
stmt_location(221, 'mode.c', 7, 0).
stmt_location(233, 'mode.c', 12, 0).
stmt_location(245, 'mode.c', 25, 0).
stmt_location(244, 'mode.c', 24, 0).
stmt_location(fun(193), 'mode.c', 1, 0).
stmt_location(fun(184), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(242, 'mode.c', 23, 0).
stmt_location(240, 'mode.c', 22, 0).
stmt_location(204, 'mode.c', 4, 1).
stmt_location(236, 'mode.c', 4, 2).
stmt_location(n(17), 'mode.c', 12, 0).
stmt_location(213, 'mode.c', 6, 1).
stmt_location(227, 'mode.c', 6, 2).
stmt_location(234, 'mode.c', 13, 0).
