:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(17), while, [cond(atomic_cond(n(19))),body(n(18))]). % merge.c: l.17
ast_node(n(8), ite, [cond(atomic_cond(n(11))), then(n(9)), else(n(10))]). % merge.c: l.6
ast_node(n(13), while, [cond(atomic_cond(n(15))),body(n(14))]). % merge.c: l.13
ast_node(n(1), while, [cond(n(3)),body(n(2))]). % merge.c: l.5
ast_node(n(3), land, [l_op(atomic_cond(n(6))),r_op(atomic_cond(n(4)))]). % merge.c: l.5
ast_node(320, assign, ['j', +(i(si(4)),'j',c(1,i(si(4))))]). % merge.c: l.9
ast_node(317, assign, ['__tmp_lin_2', 'k']). % merge.c: l.9
ast_node(315, assign, [e(+(p(i(si(4))),'result',mod(i(si(4)),'__tmp_lin_0',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr1',mod(i(si(4)),'__tmp_lin_1',c(10,i(si(4))))),c(0,i(si(4))))]). % merge.c: l.7
ast_node(n(2), seq, [n(8)]). % merge.c: l.6
ast_node(359, return, ['__retres']). % merge.c: l.30
ast_node(347, assign, [e(+(p(i(si(4))),'result',mod(i(si(4)),'__tmp_lin_6',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr2',mod(i(si(4)),'__tmp_lin_7',c(10,i(si(4))))),c(0,i(si(4))))]). % merge.c: l.18
ast_node(346, assign, ['j', +(i(si(4)),'j',c(1,i(si(4))))]). % merge.c: l.18
ast_node(330, assign, ['__tmp_lin_4', 'k']). % merge.c: l.14
ast_node(312, assign, ['k', +(i(si(4)),'k',c(1,i(si(4))))]). % merge.c: l.7
ast_node(297, cond, [inf, 'i', 'size1']). % merge.c: l.5
ast_node(357, call, ['mergeSorted', cast(p(i(si(4))),'arg1'), 'arg2', cast(p(i(si(4))),'arg3'), 'arg4', cast(p(i(si(4))),'arg5')]). % merge.c: l.29
ast_node(344, assign, ['k', +(i(si(4)),'k',c(1,i(si(4))))]). % merge.c: l.18
ast_node(307, cond, [inf, e(+(p(i(si(4))),'arr1',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr2',mod(i(si(4)),'j',c(10,i(si(4))))),c(0,i(si(4))))]). % merge.c: l.6
ast_node(n(9), seq, [311,312,313,314,315]). % merge.c: l.7
ast_node(287, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(319, assign, ['__tmp_lin_3', 'j']). % merge.c: l.9
ast_node(n(10), seq, [317,318,319,320,321]). % merge.c: l.9
ast_node(fun(217), func, ['mergeSorted', 5, 0, 0, 291]). % merge.c: l.2
ast_node(334, assign, [e(+(p(i(si(4))),'result',mod(i(si(4)),'__tmp_lin_4',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr1',mod(i(si(4)),'__tmp_lin_5',c(10,i(si(4))))),c(0,i(si(4))))]). % merge.c: l.14
ast_node(291, seq, [292,293,294,n(1),n(13),n(17)]). % merge.c: l.3
ast_node(289, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(338, cond, [inf, 'j', 'size2']). % merge.c: l.17
ast_node(314, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % merge.c: l.7
ast_node(321, assign, [e(+(p(i(si(4))),'result',mod(i(si(4)),'__tmp_lin_2',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr2',mod(i(si(4)),'__tmp_lin_3',c(10,i(si(4))))),c(0,i(si(4))))]). % merge.c: l.9
ast_node(292, assign, ['i', cast(i(si(4)),c(0,i(si(8))))]). % merge.c: l.3
ast_node(n(14), seq, [330,331,332,333,334]). % merge.c: l.14
ast_node(353, assign, ['arg2', cast(i(si(4)),c(2,i(si(8))))]). % merge.c: l.25
ast_node(351, seq, [352,353,354,355,356,357,358,359]). % merge.c: l.24
ast_node(345, assign, ['__tmp_lin_7', 'j']). % merge.c: l.18
ast_node(fun(208), func, ['__FC_assert', 4, 0, 0, 287]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(343, assign, ['__tmp_lin_6', 'k']). % merge.c: l.18
ast_node(333, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % merge.c: l.14
ast_node(332, assign, ['__tmp_lin_5', 'i']). % merge.c: l.14
ast_node(354, assign, ['arg3', cast(i(si(4)),c(3,i(si(8))))]). % merge.c: l.26
ast_node(325, cond, [inf, 'i', 'size1']). % merge.c: l.13
ast_node(313, assign, ['__tmp_lin_1', 'i']). % merge.c: l.7
ast_node(311, assign, ['__tmp_lin_0', 'k']). % merge.c: l.7
ast_node(356, assign, ['arg5', cast(i(si(4)),c(5,i(si(8))))]). % merge.c: l.28
ast_node(349, return, []). % merge.c: l.20
ast_node(358, assign, ['__retres', c(0,i(si(4)))]). % merge.c: l.30
ast_node(331, assign, ['k', +(i(si(4)),'k',c(1,i(si(4))))]). % merge.c: l.14
ast_node(301, cond, [inf, 'j', 'size2']). % merge.c: l.5
ast_node(n(18), seq, [343,344,345,346,347]). % merge.c: l.18
ast_node(355, assign, ['arg4', cast(i(si(4)),c(4,i(si(8))))]). % merge.c: l.27
ast_node(318, assign, ['k', +(i(si(4)),'k',c(1,i(si(4))))]). % merge.c: l.9
ast_node(293, assign, ['j', cast(i(si(4)),c(0,i(si(8))))]). % merge.c: l.3
ast_node(352, assign, ['arg1', cast(i(si(4)),c(1,i(si(8))))]). % merge.c: l.24
ast_node(fun(239), func, ['main', 0, 0, 1, 351]). % merge.c: l.23
ast_node(294, assign, ['k', cast(i(si(4)),c(0,i(si(8))))]). % merge.c: l.3
atomic_cond(n(11), [empty, 307]).
atomic_cond(n(15), [empty, 325]).
atomic_cond(n(6), [empty, 297]).
atomic_cond(n(4), [empty, 301]).
atomic_cond(n(19), [empty, 338]).
stmt_location(n(17), 'merge.c', 17).
stmt_location(n(8), 'merge.c', 6).
stmt_location(n(13), 'merge.c', 13).
stmt_location(n(1), 'merge.c', 5).
stmt_location(n(3), 'merge.c', 5).
stmt_location(320, 'merge.c', 9).
stmt_location(317, 'merge.c', 9).
stmt_location(315, 'merge.c', 7).
stmt_location(n(2), 'merge.c', 6).
stmt_location(359, 'merge.c', 30).
stmt_location(347, 'merge.c', 18).
stmt_location(346, 'merge.c', 18).
stmt_location(330, 'merge.c', 14).
stmt_location(312, 'merge.c', 7).
stmt_location(297, 'merge.c', 5).
stmt_location(357, 'merge.c', 29).
stmt_location(344, 'merge.c', 18).
stmt_location(307, 'merge.c', 6).
stmt_location(n(9), 'merge.c', 7).
stmt_location(287, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(319, 'merge.c', 9).
stmt_location(n(10), 'merge.c', 9).
stmt_location(fun(217), 'merge.c', 2).
stmt_location(334, 'merge.c', 14).
stmt_location(291, 'merge.c', 3).
stmt_location(289, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(338, 'merge.c', 17).
stmt_location(314, 'merge.c', 7).
stmt_location(321, 'merge.c', 9).
stmt_location(292, 'merge.c', 3).
stmt_location(n(14), 'merge.c', 14).
stmt_location(353, 'merge.c', 25).
stmt_location(351, 'merge.c', 24).
stmt_location(345, 'merge.c', 18).
stmt_location(fun(208), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(343, 'merge.c', 18).
stmt_location(333, 'merge.c', 14).
stmt_location(332, 'merge.c', 14).
stmt_location(354, 'merge.c', 26).
stmt_location(325, 'merge.c', 13).
stmt_location(313, 'merge.c', 7).
stmt_location(311, 'merge.c', 7).
stmt_location(356, 'merge.c', 28).
stmt_location(349, 'merge.c', 20).
stmt_location(358, 'merge.c', 30).
stmt_location(331, 'merge.c', 14).
stmt_location(301, 'merge.c', 5).
stmt_location(n(18), 'merge.c', 18).
stmt_location(355, 'merge.c', 27).
stmt_location(318, 'merge.c', 9).
stmt_location(293, 'merge.c', 3).
stmt_location(352, 'merge.c', 24).
stmt_location(fun(239), 'merge.c', 23).
stmt_location(294, 'merge.c', 3).
