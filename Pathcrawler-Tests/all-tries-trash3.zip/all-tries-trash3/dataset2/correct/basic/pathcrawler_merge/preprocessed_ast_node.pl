:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(320, assign, [j, +(i(si(4)), j, c(1, i(si(4))))]).
ast_node(317, assign, ['__tmp_lin_2', k]).
ast_node(315, assign, [e(+(p(i(si(4))), result, mod(i(si(4)), '__tmp_lin_0', c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr1, mod(i(si(4)), '__tmp_lin_1', c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(347, assign, [e(+(p(i(si(4))), result, mod(i(si(4)), '__tmp_lin_6', c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr2, mod(i(si(4)), '__tmp_lin_7', c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(346, assign, [j, +(i(si(4)), j, c(1, i(si(4))))]).
ast_node(330, assign, ['__tmp_lin_4', k]).
ast_node(312, assign, [k, +(i(si(4)), k, c(1, i(si(4))))]).
ast_node(297, cond, [inf, i, size1]).
ast_node(357, call, [mergeSorted, cast(p(i(si(4))), arg1), arg2, cast(p(i(si(4))), arg3), arg4, cast(p(i(si(4))), arg5)]).
ast_node(344, assign, [k, +(i(si(4)), k, c(1, i(si(4))))]).
ast_node(307, cond, [inf, e(+(p(i(si(4))), arr1, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr2, mod(i(si(4)), j, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(n(9), seq, [311, 312, 313, 314, 315]).
ast_node(319, assign, ['__tmp_lin_3', j]).
ast_node(n(10), seq, [317, 318, 319, 320, 321]).
ast_node(fun(217), func, [mergeSorted, 5, 0, 0, 291]).
ast_node(334, assign, [e(+(p(i(si(4))), result, mod(i(si(4)), '__tmp_lin_4', c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr1, mod(i(si(4)), '__tmp_lin_5', c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(291, seq, [292, 293, 294, n(1), n(13), n(17)]).
ast_node(338, cond, [inf, j, size2]).
ast_node(314, assign, [i, +(i(si(4)), i, c(1, i(si(4))))]).
ast_node(321, assign, [e(+(p(i(si(4))), result, mod(i(si(4)), '__tmp_lin_2', c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr2, mod(i(si(4)), '__tmp_lin_3', c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(292, assign, [i, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(n(14), seq, [330, 331, 332, 333, 334]).
ast_node(353, assign, [arg2, cast(i(si(4)), c(2, i(si(8))))]).
ast_node(345, assign, ['__tmp_lin_7', j]).
ast_node(343, assign, ['__tmp_lin_6', k]).
ast_node(333, assign, [i, +(i(si(4)), i, c(1, i(si(4))))]).
ast_node(332, assign, ['__tmp_lin_5', i]).
ast_node(354, assign, [arg3, cast(i(si(4)), c(3, i(si(8))))]).
ast_node(325, cond, [inf, i, size1]).
ast_node(313, assign, ['__tmp_lin_1', i]).
ast_node(311, assign, ['__tmp_lin_0', k]).
ast_node(356, assign, [arg5, cast(i(si(4)), c(5, i(si(8))))]).
ast_node(331, assign, [k, +(i(si(4)), k, c(1, i(si(4))))]).
ast_node(301, cond, [inf, j, size2]).
ast_node(n(18), seq, [343, 344, 345, 346, 347]).
ast_node(355, assign, [arg4, cast(i(si(4)), c(4, i(si(8))))]).
ast_node(318, assign, [k, +(i(si(4)), k, c(1, i(si(4))))]).
ast_node(293, assign, [j, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(352, assign, [arg1, cast(i(si(4)), c(1, i(si(8))))]).
ast_node(fun(239), func, [main, 0, 0, 1, 351]).
ast_node(294, assign, [k, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(n(8), ite, [307, n(9), n(10)]).
ast_node(n(13), while, [325, n(14)]).
ast_node(n(3), land, [297, 301]).
ast_node(n(17), while, [338, n(18)]).
ast_node(n(1), while, [n(3), n(8)]).
ast_node(358, setres, [c(0, i(si(4)))]).
ast_node(fun(208), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(351, seq, [352, 353, 354, 355, 356, 357, 358]).
ast_supernode(291, fun(217), 0, fun(217)).
ast_supernode(292, 291, 0, fun(217)).
ast_supernode(293, 291, 1, fun(217)).
ast_supernode(294, 291, 2, fun(217)).
ast_supernode(n(1), 291, 3, fun(217)).
ast_supernode(n(13), 291, 4, fun(217)).
ast_supernode(n(17), 291, 5, fun(217)).
ast_supernode(351, fun(239), 0, fun(239)).
ast_supernode(325, n(13), cond, fun(217)).
ast_supernode(338, n(17), cond, fun(217)).
ast_supernode(n(10), n(8), else, fun(217)).
ast_supernode(317, n(10), 0, fun(217)).
ast_supernode(320, n(10), 3, fun(217)).
ast_supernode(n(18), n(17), body, fun(217)).
ast_supernode(346, n(18), 3, fun(217)).
ast_supernode(347, n(18), 4, fun(217)).
ast_supernode(n(9), n(8), then, fun(217)).
ast_supernode(312, n(9), 1, fun(217)).
ast_supernode(315, n(9), 4, fun(217)).
ast_supernode(344, n(18), 1, fun(217)).
ast_supernode(319, n(10), 2, fun(217)).
ast_supernode(n(14), n(13), body, fun(217)).
ast_supernode(334, n(14), 4, fun(217)).
ast_supernode(330, n(14), 0, fun(217)).
ast_supernode(314, n(9), 3, fun(217)).
ast_supernode(321, n(10), 4, fun(217)).
ast_supernode(345, n(18), 2, fun(217)).
ast_supernode(343, n(18), 0, fun(217)).
ast_supernode(333, n(14), 3, fun(217)).
ast_supernode(332, n(14), 2, fun(217)).
ast_supernode(313, n(9), 2, fun(217)).
ast_supernode(311, n(9), 0, fun(217)).
ast_supernode(331, n(14), 1, fun(217)).
ast_supernode(n(3), n(1), cond, fun(217)).
ast_supernode(301, n(3), 1, fun(217)).
ast_supernode(297, n(3), 0, fun(217)).
ast_supernode(318, n(10), 1, fun(217)).
ast_supernode(n(8), n(1), body, fun(217)).
ast_supernode(357, 351, 5, fun(239)).
ast_supernode(352, 351, 0, fun(239)).
ast_supernode(353, 351, 1, fun(239)).
ast_supernode(354, 351, 2, fun(239)).
ast_supernode(355, 351, 3, fun(239)).
ast_supernode(356, 351, 4, fun(239)).
ast_supernode(358, 351, 6, fun(239)).
ast_supernode(307, n(8), cond, fun(217)).
topleveldec(n(3), n(1), [297, 301]).
topleveldec(307, n(8), [307]).
topleveldec(325, n(13), [325]).
topleveldec(338, n(17), [338]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(325, 1, 0, n(13)).
immediate_dom_branch_loop_iter(338, 1, 0, n(17)).
immediate_dom_branch_loop_iter(301, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(n(3), true(and(true(297), true(301))), [297, 301]).
dec_path_and_coverage(n(3), false(and(false(297))), [-297]).
dec_path_and_coverage(n(3), false(and(true(297), false(301))), [297, -301]).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(17), 'merge.c', 17, 0).
stmt_location(n(8), 'merge.c', 6, 0).
stmt_location(n(13), 'merge.c', 13, 0).
stmt_location(n(1), 'merge.c', 5, 0).
stmt_location(n(3), 'merge.c', 5, 0).
stmt_location(317, 'merge.c', 9, 1).
stmt_location(357, 'merge.c', 29, 0).
stmt_location(307, 'merge.c', 6, 0).
stmt_location(n(9), 'merge.c', 7, 0).
stmt_location(n(10), 'merge.c', 9, 0).
stmt_location(fun(217), 'merge.c', 2, 0).
stmt_location(330, 'merge.c', 14, 1).
stmt_location(291, 'merge.c', 3, 0).
stmt_location(338, 'merge.c', 17, 0).
stmt_location(n(14), 'merge.c', 14, 0).
stmt_location(353, 'merge.c', 25, 0).
stmt_location(351, 'merge.c', 24, 0).
stmt_location(fun(208), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(343, 'merge.c', 18, 1).
stmt_location(344, 'merge.c', 18, 2).
stmt_location(345, 'merge.c', 18, 3).
stmt_location(346, 'merge.c', 18, 4).
stmt_location(347, 'merge.c', 18, 5).
stmt_location(354, 'merge.c', 26, 0).
stmt_location(325, 'merge.c', 13, 0).
stmt_location(311, 'merge.c', 7, 1).
stmt_location(312, 'merge.c', 7, 2).
stmt_location(313, 'merge.c', 7, 3).
stmt_location(314, 'merge.c', 7, 4).
stmt_location(315, 'merge.c', 7, 5).
stmt_location(356, 'merge.c', 28, 0).
stmt_location(358, 'merge.c', 30, 0).
stmt_location(331, 'merge.c', 14, 2).
stmt_location(332, 'merge.c', 14, 3).
stmt_location(333, 'merge.c', 14, 4).
stmt_location(334, 'merge.c', 14, 5).
stmt_location(297, 'merge.c', 5, 1).
stmt_location(301, 'merge.c', 5, 2).
stmt_location(n(18), 'merge.c', 18, 0).
stmt_location(355, 'merge.c', 27, 0).
stmt_location(318, 'merge.c', 9, 2).
stmt_location(319, 'merge.c', 9, 3).
stmt_location(320, 'merge.c', 9, 4).
stmt_location(321, 'merge.c', 9, 5).
stmt_location(292, 'merge.c', 3, 1).
stmt_location(293, 'merge.c', 3, 2).
stmt_location(352, 'merge.c', 24, 0).
stmt_location(fun(239), 'merge.c', 23, 0).
stmt_location(294, 'merge.c', 3, 3).
