int binarySearch(int arr[], int size, int target) {
    int low = 0L, high = size - 1L;
    while (low <= high) {
        int mid = low + (high - low) / 2L;
        if (arr[mid % 10] == target)
            return mid;
        if (arr[mid % 10] < target)
            low = mid + 1L;
        else
            high = mid - 1L;
    }
    return -1L;
}


int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = binarySearch(arg1, arg2, arg3);
    return 0;
}
