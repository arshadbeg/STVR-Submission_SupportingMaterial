struct Node {
    int data;
    struct Node* next;
};

struct Node* insertAtHead(struct Node* head, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = head;
    return newNode;
}


int main() {
    struct Node head safe_arr0[10] = {0};
    struct Node head* arg1 = safe_arr0;
    int arg2 = 2L;
    struct Node* result = insertAtHead(arg1, arg2);
    return 0;
}
