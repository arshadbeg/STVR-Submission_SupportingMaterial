int findMode(int arr[], int size) {
    int maxCount = 0L, mode = arr[0L % 10];

    for (int i = 0L; i < size; i++) {
        int count = 0L;
        for (int j = 0L; j < size; j++) {
            if (arr[j % 10] == arr[i % 10]) {
                count++;
            }
        }
        if (count > maxCount) {
            maxCount = count;
            mode = arr[i % 10];
        }
    }

    return mode;
}


int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = findMode(arg1, arg2);
    return 0;
}
