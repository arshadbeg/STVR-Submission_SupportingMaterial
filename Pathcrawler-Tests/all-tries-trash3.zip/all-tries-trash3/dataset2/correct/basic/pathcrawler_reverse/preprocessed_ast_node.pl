:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(n(2), seq, [135, 136, 137, 138, 139]).
ast_node(125, seq, [126, 127, n(1)]).
ast_node(139, assign, [end, -(i(si(4)), end, c(1, i(si(4))))]).
ast_node(127, assign, [end, cast(i(si(4)), -(i(si(8)), cast(i(si(8)), size), c(1, i(si(8)))))]).
ast_node(146, call, [reverseArray, cast(p(i(si(4))), arg1), arg2]).
ast_node(126, assign, [start, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(fun(186), func, [reverseArray, 2, 0, 0, 125]).
ast_node(135, assign, [temp, e(+(p(i(si(4))), arr, mod(i(si(4)), start, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(136, assign, [e(+(p(i(si(4))), arr, mod(i(si(4)), start, c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr, mod(i(si(4)), end, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(138, assign, [start, +(i(si(4)), start, c(1, i(si(4))))]).
ast_node(fun(194), func, [main, 0, 0, 1, 143]).
ast_node(137, assign, [e(+(p(i(si(4))), arr, mod(i(si(4)), end, c(10, i(si(4))))), c(0, i(si(4)))), temp]).
ast_node(144, assign, [arg1, cast(i(si(4)), c(1, i(si(8))))]).
ast_node(145, assign, [arg2, cast(i(si(4)), c(2, i(si(8))))]).
ast_node(130, cond, [inf, start, end]).
ast_node(n(1), while, [130, n(2)]).
ast_node(147, setres, [c(0, i(si(4)))]).
ast_node(fun(177), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(143, seq, [144, 145, 146, 147]).
ast_supernode(125, fun(186), 0, fun(186)).
ast_supernode(143, fun(194), 0, fun(194)).
ast_supernode(144, 143, 0, fun(194)).
ast_supernode(145, 143, 1, fun(194)).
ast_supernode(146, 143, 2, fun(194)).
ast_supernode(147, 143, 3, fun(194)).
ast_supernode(126, 125, 0, fun(186)).
ast_supernode(127, 125, 1, fun(186)).
ast_supernode(n(1), 125, 2, fun(186)).
ast_supernode(n(2), n(1), body, fun(186)).
ast_supernode(135, n(2), 0, fun(186)).
ast_supernode(136, n(2), 1, fun(186)).
ast_supernode(137, n(2), 2, fun(186)).
ast_supernode(138, n(2), 3, fun(186)).
ast_supernode(139, n(2), 4, fun(186)).
ast_supernode(130, n(1), cond, fun(186)).
topleveldec(130, n(1), [130]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(130, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(1), 'reverse.c', 3, 0).
stmt_location(n(2), 'reverse.c', 4, 0).
stmt_location(125, 'reverse.c', 2, 0).
stmt_location(147, 'reverse.c', 17, 0).
stmt_location(139, 'reverse.c', 8, 0).
stmt_location(146, 'reverse.c', 16, 0).
stmt_location(126, 'reverse.c', 2, 1).
stmt_location(127, 'reverse.c', 2, 2).
stmt_location(fun(186), 'reverse.c', 1, 0).
stmt_location(135, 'reverse.c', 4, 0).
stmt_location(fun(177), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(136, 'reverse.c', 5, 0).
stmt_location(138, 'reverse.c', 7, 0).
stmt_location(fun(194), 'reverse.c', 13, 0).
stmt_location(137, 'reverse.c', 6, 0).
stmt_location(144, 'reverse.c', 14, 0).
stmt_location(145, 'reverse.c', 15, 0).
stmt_location(130, 'reverse.c', 3, 0).
stmt_location(143, 'reverse.c', 14, 0).
