:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(1), for, [cond(atomic_cond(n(4))),body(n(2)),action(n(3))]). % sorted.c: l.2
ast_node(n(6), ite, [cond(atomic_cond(n(9))), then(n(7)), else(empty)]). % sorted.c: l.3
ast_node(n(2), seq, [n(6)]). % sorted.c: l.3
ast_node(139, seq, [140,n(1),158,159]). % sorted.c: l.2
ast_node(n(8), seq, []). % <unknown location>: l.0
ast_node(n(7), seq, [153,154]). % sorted.c: l.4
ast_node(fun(178), func, ['__FC_assert', 4, 0, 0, 135]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(153, assign, ['__retres', cast(i(si(4)),c(0,i(si(8))))]). % sorted.c: l.4
ast_node(135, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(164, rescall, ['isSorted', '__tmp_lin_0', cast(p(i(si(4))),'arg1'), 'arg2']). % sorted.c: l.13
ast_node(158, assign, ['__retres', cast(i(si(4)),c(1,i(si(8))))]). % sorted.c: l.6
ast_node(154, return, ['__retres']). % sorted.c: l.4
ast_node(137, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(156, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % sorted.c: l.2
ast_node(161, seq, [162,163,164,165,166,167]). % sorted.c: l.11
ast_node(167, return, ['__retres']). % sorted.c: l.14
ast_node(fun(187), func, ['isSorted', 2, 0, 1, 139]). % sorted.c: l.1
ast_node(165, assign, ['result', '__tmp_lin_0']). % sorted.c: l.13
ast_node(163, assign, ['arg2', cast(i(si(4)),c(2,i(si(8))))]). % sorted.c: l.12
ast_node(162, assign, ['arg1', cast(i(si(4)),c(1,i(si(8))))]). % sorted.c: l.11
ast_node(n(3), seq, [156]). % sorted.c: l.2
ast_node(fun(193), func, ['main', 0, 0, 1, 161]). % sorted.c: l.10
ast_node(159, return, ['__retres']). % sorted.c: l.6
ast_node(148, cond, [sup, e(+(p(i(si(4))),'arr',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr',+(i(si(8)),cast(i(si(8)),'i'),mod(i(si(8)),c(1,i(si(8))),cast(i(si(8)),c(10,i(si(4))))))),c(0,i(si(4))))]). % sorted.c: l.3
ast_node(166, assign, ['__retres', c(0,i(si(4)))]). % sorted.c: l.14
ast_node(140, assign, ['i', cast(i(si(4)),c(0,i(si(8))))]). % sorted.c: l.2
ast_node(143, cond, [inf, cast(i(si(8)),'i'), -(i(si(8)),cast(i(si(8)),'size'),c(1,i(si(8))))]). % sorted.c: l.2
atomic_cond(n(9), [empty, 148]).
atomic_cond(n(4), [empty, 143]).
stmt_location(n(1), 'sorted.c', 2).
stmt_location(n(6), 'sorted.c', 3).
stmt_location(n(2), 'sorted.c', 3).
stmt_location(139, 'sorted.c', 2).
stmt_location(n(8), '<unknown location>', 0).
stmt_location(n(7), 'sorted.c', 4).
stmt_location(fun(178), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(153, 'sorted.c', 4).
stmt_location(135, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(164, 'sorted.c', 13).
stmt_location(158, 'sorted.c', 6).
stmt_location(154, 'sorted.c', 4).
stmt_location(137, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(156, 'sorted.c', 2).
stmt_location(161, 'sorted.c', 11).
stmt_location(167, 'sorted.c', 14).
stmt_location(fun(187), 'sorted.c', 1).
stmt_location(165, 'sorted.c', 13).
stmt_location(163, 'sorted.c', 12).
stmt_location(162, 'sorted.c', 11).
stmt_location(n(3), 'sorted.c', 2).
stmt_location(fun(193), 'sorted.c', 10).
stmt_location(159, 'sorted.c', 6).
stmt_location(148, 'sorted.c', 3).
stmt_location(166, 'sorted.c', 14).
stmt_location(140, 'sorted.c', 2).
stmt_location(143, 'sorted.c', 2).
