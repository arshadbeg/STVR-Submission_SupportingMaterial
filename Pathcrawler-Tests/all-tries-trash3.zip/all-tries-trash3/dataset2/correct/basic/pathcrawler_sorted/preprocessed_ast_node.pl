:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(164, rescall, [isSorted, '__tmp_lin_0', cast(p(i(si(4))), arg1), arg2]).
ast_node(156, assign, [i, +(i(si(4)), i, c(1, i(si(4))))]).
ast_node(fun(187), func, [isSorted, 2, 0, 1, 139]).
ast_node(165, assign, [result, '__tmp_lin_0']).
ast_node(163, assign, [arg2, cast(i(si(4)), c(2, i(si(8))))]).
ast_node(162, assign, [arg1, cast(i(si(4)), c(1, i(si(8))))]).
ast_node(fun(193), func, [main, 0, 0, 1, 161]).
ast_node(148, cond, [sup, e(+(p(i(si(4))), arr, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(4))), arr, +(i(si(8)), cast(i(si(8)), i), mod(i(si(8)), c(1, i(si(8))), cast(i(si(8)), c(10, i(si(4))))))), c(0, i(si(4))))]).
ast_node(140, assign, [i, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(143, cond, [inf, cast(i(si(8)), i), -(i(si(8)), cast(i(si(8)), size), c(1, i(si(8))))]).
ast_node(n(6), ite, [148, n(7), empty]).
ast_node(n(1), for, [143, n(6), 156]).
ast_node(153, setres, [cast(i(si(4)), c(0, i(si(8))))]).
ast_node(158, setres, [cast(i(si(4)), c(1, i(si(8))))]).
ast_node(166, setres, [c(0, i(si(4)))]).
ast_node(fun(178), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(154, cflow, [return]).
ast_node(n(7), seqg, [153, 154]).
ast_node(preprocess_node(2), seqg, [140, n(1)]).
ast_node(161, seq, [162, 163, 164, 165, 166]).
ast_node(139, set, [preprocess_node(2), 158]).
ast_supernode(139, fun(187), 0, fun(187)).
ast_supernode(161, fun(193), 0, fun(193)).
ast_supernode(n(6), n(1), body, fun(187)).
ast_supernode(156, n(1), action, fun(187)).
ast_supernode(preprocess_node(2), 139, 0, fun(187)).
ast_supernode(140, preprocess_node(2), 0, fun(187)).
ast_supernode(n(1), preprocess_node(2), 1, fun(187)).
ast_supernode(158, 139, 1, fun(187)).
ast_supernode(164, 161, 2, fun(193)).
ast_supernode(n(7), n(6), then, fun(187)).
ast_supernode(153, n(7), 0, fun(187)).
ast_supernode(154, n(7), 1, fun(187)).
ast_supernode(162, 161, 0, fun(193)).
ast_supernode(163, 161, 1, fun(193)).
ast_supernode(165, 161, 3, fun(193)).
ast_supernode(166, 161, 4, fun(193)).
ast_supernode(148, n(6), cond, fun(187)).
ast_supernode(143, n(1), cond, fun(187)).
topleveldec(148, n(6), [148]).
topleveldec(143, n(1), [143]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(143, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(1), 'sorted.c', 2, 0).
stmt_location(n(6), 'sorted.c', 3, 0).
stmt_location(n(7), 'sorted.c', 4, 0).
stmt_location(fun(178), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(153, 'sorted.c', 4, 0).
stmt_location(164, 'sorted.c', 13, 0).
stmt_location(158, 'sorted.c', 6, 0).
stmt_location(154, 'sorted.c', 4, 0).
stmt_location(161, 'sorted.c', 11, 0).
stmt_location(fun(187), 'sorted.c', 1, 0).
stmt_location(165, 'sorted.c', 13, 0).
stmt_location(163, 'sorted.c', 12, 0).
stmt_location(162, 'sorted.c', 11, 0).
stmt_location(139, 'sorted.c', 2, 1).
stmt_location(fun(193), 'sorted.c', 10, 0).
stmt_location(148, 'sorted.c', 3, 0).
stmt_location(166, 'sorted.c', 14, 0).
stmt_location(140, 'sorted.c', 2, 1).
stmt_location(156, 'sorted.c', 2, 2).
stmt_location(143, 'sorted.c', 2, 0).
stmt_location(preprocess_node(2), 'sorted.c', 2, 1).
