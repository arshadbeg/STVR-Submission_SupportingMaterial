:- module(fixed_domain).
:- export const_input/2.
:- export const_dim_input/3.
:- export init_input/2.
const_input(0, 0).
const_input(_122397, _122400) :- init_input(_122397, _122400).
const_dim_input(0, 0, 0).
init_input(0, 0).
