:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(1), for, [cond(atomic_cond(n(4))),body(n(2)),action(n(3))]). % max.c: l.3
ast_node(n(6), ite, [cond(atomic_cond(n(9))), then(n(7)), else(empty)]). % max.c: l.4
ast_node(n(2), seq, [n(6)]). % max.c: l.4
ast_node(127, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(146, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % max.c: l.3
ast_node(n(8), seq, []). % <unknown location>: l.0
ast_node(152, assign, ['arg2', cast(i(si(4)),c(2,i(si(8))))]). % max.c: l.13
ast_node(n(7), seq, [144]). % max.c: l.5
ast_node(fun(178), func, ['__FC_assert', 4, 0, 0, 127]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(153, rescall, ['findMax', '__tmp_lin_0', cast(p(i(si(4))),'arg1'), 'arg2']). % max.c: l.14
ast_node(141, cond, [sup, e(+(p(i(si(4))),'arr',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), 'max']). % max.c: l.4
ast_node(136, cond, [inf, 'i', 'size']). % max.c: l.3
ast_node(151, assign, ['arg1', cast(i(si(4)),c(1,i(si(8))))]). % max.c: l.12
ast_node(fun(194), func, ['main', 0, 0, 1, 150]). % max.c: l.11
ast_node(154, assign, ['result', '__tmp_lin_0']). % max.c: l.14
ast_node(133, assign, ['i', cast(i(si(4)),c(1,i(si(8))))]). % max.c: l.3
ast_node(156, return, ['__retres']). % max.c: l.15
ast_node(144, assign, ['max', e(+(p(i(si(4))),'arr',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))]). % max.c: l.5
ast_node(155, assign, ['__retres', c(0,i(si(4)))]). % max.c: l.15
ast_node(131, seq, [132,133,n(1),148]). % max.c: l.2
ast_node(fun(187), func, ['findMax', 2, 0, 1, 131]). % max.c: l.1
ast_node(150, seq, [151,152,153,154,155,156]). % max.c: l.12
ast_node(n(3), seq, [146]). % max.c: l.3
ast_node(132, assign, ['max', e(+(p(i(si(4))),'arr',mod(i(si(8)),c(0,i(si(8))),cast(i(si(8)),c(10,i(si(4)))))),c(0,i(si(4))))]). % max.c: l.2
ast_node(148, return, ['max']). % max.c: l.7
ast_node(129, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
atomic_cond(n(9), [empty, 141]).
atomic_cond(n(4), [empty, 136]).
stmt_location(n(1), 'max.c', 3).
stmt_location(n(6), 'max.c', 4).
stmt_location(n(2), 'max.c', 4).
stmt_location(127, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(146, 'max.c', 3).
stmt_location(n(8), '<unknown location>', 0).
stmt_location(152, 'max.c', 13).
stmt_location(n(7), 'max.c', 5).
stmt_location(fun(178), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(153, 'max.c', 14).
stmt_location(141, 'max.c', 4).
stmt_location(136, 'max.c', 3).
stmt_location(151, 'max.c', 12).
stmt_location(fun(194), 'max.c', 11).
stmt_location(154, 'max.c', 14).
stmt_location(133, 'max.c', 3).
stmt_location(156, 'max.c', 15).
stmt_location(144, 'max.c', 5).
stmt_location(155, 'max.c', 15).
stmt_location(131, 'max.c', 2).
stmt_location(fun(187), 'max.c', 1).
stmt_location(150, 'max.c', 12).
stmt_location(n(3), 'max.c', 3).
stmt_location(132, 'max.c', 2).
stmt_location(148, 'max.c', 7).
stmt_location(129, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
