:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(10), ite, [cond(atomic_cond(n(13))), then(n(11)), else(n(12))]). % binarysearch.c: l.7
ast_node(n(5), ite, [cond(atomic_cond(n(8))), then(n(6)), else(empty)]). % binarysearch.c: l.5
ast_node(n(1), while, [cond(atomic_cond(n(3))),body(n(2))]). % binarysearch.c: l.3
ast_node(195, assign, ['arg2', cast(i(si(4)),c(2,i(si(8))))]). % binarysearch.c: l.18
ast_node(n(2), seq, [175,n(5),n(10)]). % binarysearch.c: l.4
ast_node(n(7), seq, []). % <unknown location>: l.0
ast_node(176, cond, [egal, e(+(p(i(si(4))),'arr',mod(i(si(4)),'mid',c(10,i(si(4))))),c(0,i(si(4)))), 'target']). % binarysearch.c: l.5
ast_node(n(12), seq, [188]). % binarysearch.c: l.10
ast_node(170, cond, [infegal, 'low', 'high']). % binarysearch.c: l.3
ast_node(n(11), seq, [187]). % binarysearch.c: l.8
ast_node(194, assign, ['arg1', cast(i(si(4)),c(1,i(si(8))))]). % binarysearch.c: l.17
ast_node(198, assign, ['result', '__tmp_lin_0']). % binarysearch.c: l.20
ast_node(181, assign, ['__retres', 'mid']). % binarysearch.c: l.6
ast_node(197, rescall, ['binarySearch', '__tmp_lin_0', cast(p(i(si(4))),'arg1'), 'arg2', 'arg3']). % binarysearch.c: l.20
ast_node(n(6), seq, [181,182]). % binarysearch.c: l.6
ast_node(196, assign, ['arg3', cast(i(si(4)),c(3,i(si(8))))]). % binarysearch.c: l.19
ast_node(175, assign, ['mid', cast(i(si(4)),+(i(si(8)),cast(i(si(8)),'low'),/(i(si(8)),cast(i(si(8)),-(i(si(4)),'high','low')),c(2,i(si(8))))))]). % binarysearch.c: l.4
ast_node(fun(196), func, ['binarySearch', 3, 0, 1, 165]). % binarysearch.c: l.1
ast_node(161, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(187, assign, ['low', cast(i(si(4)),+(i(si(8)),cast(i(si(8)),'mid'),c(1,i(si(8)))))]). % binarysearch.c: l.8
ast_node(167, assign, ['high', cast(i(si(4)),-(i(si(8)),cast(i(si(8)),'size'),c(1,i(si(8)))))]). % binarysearch.c: l.2
ast_node(fun(187), func, ['__FC_assert', 4, 0, 0, 161]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(190, assign, ['__retres', cast(i(si(4)),'-'(i(si(8)),c(1,i(si(8)))))]). % binarysearch.c: l.12
ast_node(165, seq, [166,167,n(1),190,191]). % binarysearch.c: l.2
ast_node(fun(206), func, ['main', 0, 0, 1, 193]). % binarysearch.c: l.16
ast_node(163, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(193, seq, [194,195,196,197,198,199,200]). % binarysearch.c: l.17
ast_node(200, return, ['__retres']). % binarysearch.c: l.21
ast_node(184, cond, [inf, e(+(p(i(si(4))),'arr',mod(i(si(4)),'mid',c(10,i(si(4))))),c(0,i(si(4)))), 'target']). % binarysearch.c: l.7
ast_node(188, assign, ['high', cast(i(si(4)),-(i(si(8)),cast(i(si(8)),'mid'),c(1,i(si(8)))))]). % binarysearch.c: l.10
ast_node(199, assign, ['__retres', c(0,i(si(4)))]). % binarysearch.c: l.21
ast_node(191, return, ['__retres']). % binarysearch.c: l.12
ast_node(166, assign, ['low', cast(i(si(4)),c(0,i(si(8))))]). % binarysearch.c: l.2
ast_node(182, return, ['__retres']). % binarysearch.c: l.6
atomic_cond(n(8), [empty, 176]).
atomic_cond(n(13), [empty, 184]).
atomic_cond(n(3), [empty, 170]).
stmt_location(n(10), 'binarysearch.c', 7).
stmt_location(n(5), 'binarysearch.c', 5).
stmt_location(n(1), 'binarysearch.c', 3).
stmt_location(195, 'binarysearch.c', 18).
stmt_location(n(2), 'binarysearch.c', 4).
stmt_location(n(7), '<unknown location>', 0).
stmt_location(176, 'binarysearch.c', 5).
stmt_location(n(12), 'binarysearch.c', 10).
stmt_location(170, 'binarysearch.c', 3).
stmt_location(n(11), 'binarysearch.c', 8).
stmt_location(194, 'binarysearch.c', 17).
stmt_location(198, 'binarysearch.c', 20).
stmt_location(181, 'binarysearch.c', 6).
stmt_location(197, 'binarysearch.c', 20).
stmt_location(n(6), 'binarysearch.c', 6).
stmt_location(196, 'binarysearch.c', 19).
stmt_location(175, 'binarysearch.c', 4).
stmt_location(fun(196), 'binarysearch.c', 1).
stmt_location(161, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(187, 'binarysearch.c', 8).
stmt_location(167, 'binarysearch.c', 2).
stmt_location(fun(187), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(190, 'binarysearch.c', 12).
stmt_location(165, 'binarysearch.c', 2).
stmt_location(fun(206), 'binarysearch.c', 16).
stmt_location(163, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(193, 'binarysearch.c', 17).
stmt_location(200, 'binarysearch.c', 21).
stmt_location(184, 'binarysearch.c', 7).
stmt_location(188, 'binarysearch.c', 10).
stmt_location(199, 'binarysearch.c', 21).
stmt_location(191, 'binarysearch.c', 12).
stmt_location(166, 'binarysearch.c', 2).
stmt_location(182, 'binarysearch.c', 6).
