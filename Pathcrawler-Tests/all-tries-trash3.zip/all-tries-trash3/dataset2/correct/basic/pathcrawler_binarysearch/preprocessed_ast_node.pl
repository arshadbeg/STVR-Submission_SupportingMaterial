:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(195, assign, [arg2, cast(i(si(4)), c(2, i(si(8))))]).
ast_node(176, cond, [egal, e(+(p(i(si(4))), arr, mod(i(si(4)), mid, c(10, i(si(4))))), c(0, i(si(4)))), target]).
ast_node(170, cond, [infegal, low, high]).
ast_node(194, assign, [arg1, cast(i(si(4)), c(1, i(si(8))))]).
ast_node(198, assign, [result, '__tmp_lin_0']).
ast_node(197, rescall, [binarySearch, '__tmp_lin_0', cast(p(i(si(4))), arg1), arg2, arg3]).
ast_node(196, assign, [arg3, cast(i(si(4)), c(3, i(si(8))))]).
ast_node(175, assign, [mid, cast(i(si(4)), +(i(si(8)), cast(i(si(8)), low), /(i(si(8)), cast(i(si(8)), -(i(si(4)), high, low)), c(2, i(si(8))))))]).
ast_node(fun(196), func, [binarySearch, 3, 0, 1, 165]).
ast_node(187, assign, [low, cast(i(si(4)), +(i(si(8)), cast(i(si(8)), mid), c(1, i(si(8)))))]).
ast_node(167, assign, [high, cast(i(si(4)), -(i(si(8)), cast(i(si(8)), size), c(1, i(si(8)))))]).
ast_node(fun(206), func, [main, 0, 0, 1, 193]).
ast_node(184, cond, [inf, e(+(p(i(si(4))), arr, mod(i(si(4)), mid, c(10, i(si(4))))), c(0, i(si(4)))), target]).
ast_node(188, assign, [high, cast(i(si(4)), -(i(si(8)), cast(i(si(8)), mid), c(1, i(si(8)))))]).
ast_node(166, assign, [low, cast(i(si(4)), c(0, i(si(8))))]).
ast_node(n(5), ite, [176, n(6), empty]).
ast_node(n(1), while, [170, n(2)]).
ast_node(n(10), ite, [184, 187, 188]).
ast_node(181, setres, [mid]).
ast_node(190, setres, [cast(i(si(4)), i(si(8)) - c(1, i(si(8))))]).
ast_node(199, setres, [c(0, i(si(4)))]).
ast_node(fun(187), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(193, seq, [194, 195, 196, 197, 198, 199]).
ast_node(182, cflow, [return]).
ast_node(n(6), seqg, [181, 182]).
ast_node(preprocess_node(2), seqg, [175, n(5)]).
ast_node(preprocess_node(4), seqg, [166, 167, n(1)]).
ast_node(n(2), set, [preprocess_node(2), n(10)]).
ast_node(165, set, [preprocess_node(4), 190]).
ast_supernode(165, fun(196), 0, fun(196)).
ast_supernode(193, fun(206), 0, fun(206)).
ast_supernode(194, 193, 0, fun(206)).
ast_supernode(195, 193, 1, fun(206)).
ast_supernode(196, 193, 2, fun(206)).
ast_supernode(197, 193, 3, fun(206)).
ast_supernode(198, 193, 4, fun(206)).
ast_supernode(199, 193, 5, fun(206)).
ast_supernode(170, n(1), cond, fun(196)).
ast_supernode(preprocess_node(4), 165, 0, fun(196)).
ast_supernode(166, preprocess_node(4), 0, fun(196)).
ast_supernode(167, preprocess_node(4), 1, fun(196)).
ast_supernode(n(1), preprocess_node(4), 2, fun(196)).
ast_supernode(190, 165, 1, fun(196)).
ast_supernode(n(2), n(1), body, fun(196)).
ast_supernode(preprocess_node(2), n(2), 0, fun(196)).
ast_supernode(n(5), preprocess_node(2), 1, fun(196)).
ast_supernode(n(6), n(5), then, fun(196)).
ast_supernode(181, n(6), 0, fun(196)).
ast_supernode(182, n(6), 1, fun(196)).
ast_supernode(176, n(5), cond, fun(196)).
ast_supernode(n(10), n(2), 1, fun(196)).
ast_supernode(184, n(10), cond, fun(196)).
ast_supernode(188, n(10), else, fun(196)).
ast_supernode(187, n(10), then, fun(196)).
ast_supernode(175, preprocess_node(2), 0, fun(196)).
topleveldec(176, n(5), [176]).
topleveldec(184, n(10), [184]).
topleveldec(170, n(1), [170]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(170, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(10), 'binarysearch.c', 7, 0).
stmt_location(n(5), 'binarysearch.c', 5, 0).
stmt_location(n(1), 'binarysearch.c', 3, 0).
stmt_location(195, 'binarysearch.c', 18, 0).
stmt_location(n(2), 'binarysearch.c', 4, 0).
stmt_location(176, 'binarysearch.c', 5, 0).
stmt_location(170, 'binarysearch.c', 3, 0).
stmt_location(194, 'binarysearch.c', 17, 0).
stmt_location(198, 'binarysearch.c', 20, 0).
stmt_location(181, 'binarysearch.c', 6, 0).
stmt_location(197, 'binarysearch.c', 20, 0).
stmt_location(n(6), 'binarysearch.c', 6, 0).
stmt_location(196, 'binarysearch.c', 19, 0).
stmt_location(175, 'binarysearch.c', 4, 0).
stmt_location(fun(196), 'binarysearch.c', 1, 0).
stmt_location(187, 'binarysearch.c', 8, 0).
stmt_location(fun(187), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(190, 'binarysearch.c', 12, 0).
stmt_location(165, 'binarysearch.c', 2, 0).
stmt_location(fun(206), 'binarysearch.c', 16, 0).
stmt_location(193, 'binarysearch.c', 17, 0).
stmt_location(184, 'binarysearch.c', 7, 0).
stmt_location(188, 'binarysearch.c', 10, 0).
stmt_location(199, 'binarysearch.c', 21, 0).
stmt_location(166, 'binarysearch.c', 2, 1).
stmt_location(167, 'binarysearch.c', 2, 2).
stmt_location(182, 'binarysearch.c', 6, 0).
stmt_location(preprocess_node(2), 'binarysearch.c', 4, 0).
stmt_location(preprocess_node(4), 'binarysearch.c', 2, 0).
