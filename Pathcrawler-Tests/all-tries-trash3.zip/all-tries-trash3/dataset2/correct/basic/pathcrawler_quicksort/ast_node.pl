:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(1), for, [cond(atomic_cond(n(4))),body(n(2)),action(n(3))]). % quicksort.c: l.4
ast_node(n(6), ite, [cond(atomic_cond(n(9))), then(n(7)), else(empty)]). % quicksort.c: l.5
ast_node(195, return, ['__retres']). % quicksort.c: l.15
ast_node(n(2), seq, [n(6)]). % quicksort.c: l.5
ast_node(203, assign, ['__retres', c(0,i(si(4)))]). % quicksort.c: l.25
ast_node(192, assign, [e(+(p(i(si(4))),'arr',+(i(si(8)),cast(i(si(8)),'i'),mod(i(si(8)),c(1,i(si(8))),cast(i(si(8)),c(10,i(si(4))))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr',mod(i(si(4)),'high',c(10,i(si(4))))),c(0,i(si(4))))]). % quicksort.c: l.13
ast_node(169, seq, [170,171,172,n(1),191,192,193,194,195]). % quicksort.c: l.2
ast_node(fun(192), func, ['__FC_assert', 4, 0, 0, 165]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(204, return, ['__retres']). % quicksort.c: l.25
ast_node(201, rescall, ['partition', '__tmp_lin_0', cast(p(i(si(4))),'arg1'), 'arg2', 'arg3']). % quicksort.c: l.24
ast_node(n(8), seq, []). % <unknown location>: l.0
ast_node(fun(201), func, ['partition', 3, 0, 1, 169]). % quicksort.c: l.1
ast_node(186, assign, [e(+(p(i(si(4))),'arr',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(4))),'arr',mod(i(si(4)),'j',c(10,i(si(4))))),c(0,i(si(4))))]). % quicksort.c: l.8
ast_node(n(7), seq, [184,185,186,187]). % quicksort.c: l.6
ast_node(171, assign, ['i', cast(i(si(4)),-(i(si(8)),cast(i(si(8)),'low'),c(1,i(si(8)))))]). % quicksort.c: l.3
ast_node(170, assign, ['pivot', e(+(p(i(si(4))),'arr',mod(i(si(4)),'high',c(10,i(si(4))))),c(0,i(si(4))))]). % quicksort.c: l.2
ast_node(202, assign, ['result', '__tmp_lin_0']). % quicksort.c: l.24
ast_node(fun(214), func, ['main', 0, 0, 1, 197]). % quicksort.c: l.20
ast_node(194, assign, ['__retres', cast(i(si(4)),+(i(si(8)),cast(i(si(8)),'i'),c(1,i(si(8)))))]). % quicksort.c: l.15
ast_node(180, cond, [infegal, e(+(p(i(si(4))),'arr',mod(i(si(4)),'j',c(10,i(si(4))))),c(0,i(si(4)))), 'pivot']). % quicksort.c: l.5
ast_node(198, assign, ['arg1', cast(i(si(4)),c(1,i(si(8))))]). % quicksort.c: l.21
ast_node(197, seq, [198,199,200,201,202,203,204]). % quicksort.c: l.21
ast_node(175, cond, [inf, 'j', 'high']). % quicksort.c: l.4
ast_node(187, assign, [e(+(p(i(si(4))),'arr',mod(i(si(4)),'j',c(10,i(si(4))))),c(0,i(si(4)))), 'temp']). % quicksort.c: l.9
ast_node(167, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(165, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(189, assign, ['j', +(i(si(4)),'j',c(1,i(si(4))))]). % quicksort.c: l.4
ast_node(n(3), seq, [189]). % quicksort.c: l.4
ast_node(185, assign, ['temp', e(+(p(i(si(4))),'arr',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))]). % quicksort.c: l.7
ast_node(193, assign, [e(+(p(i(si(4))),'arr',mod(i(si(4)),'high',c(10,i(si(4))))),c(0,i(si(4)))), 'temp_0']). % quicksort.c: l.14
ast_node(200, assign, ['arg3', cast(i(si(4)),c(3,i(si(8))))]). % quicksort.c: l.23
ast_node(184, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % quicksort.c: l.6
ast_node(199, assign, ['arg2', cast(i(si(4)),c(2,i(si(8))))]). % quicksort.c: l.22
ast_node(191, assign, ['temp_0', e(+(p(i(si(4))),'arr',+(i(si(8)),cast(i(si(8)),'i'),mod(i(si(8)),c(1,i(si(8))),cast(i(si(8)),c(10,i(si(4))))))),c(0,i(si(4))))]). % quicksort.c: l.12
ast_node(172, assign, ['j', 'low']). % quicksort.c: l.4
atomic_cond(n(9), [empty, 180]).
atomic_cond(n(4), [empty, 175]).
stmt_location(n(1), 'quicksort.c', 4).
stmt_location(n(6), 'quicksort.c', 5).
stmt_location(195, 'quicksort.c', 15).
stmt_location(n(2), 'quicksort.c', 5).
stmt_location(203, 'quicksort.c', 25).
stmt_location(192, 'quicksort.c', 13).
stmt_location(169, 'quicksort.c', 2).
stmt_location(fun(192), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(204, 'quicksort.c', 25).
stmt_location(201, 'quicksort.c', 24).
stmt_location(n(8), '<unknown location>', 0).
stmt_location(fun(201), 'quicksort.c', 1).
stmt_location(186, 'quicksort.c', 8).
stmt_location(n(7), 'quicksort.c', 6).
stmt_location(171, 'quicksort.c', 3).
stmt_location(170, 'quicksort.c', 2).
stmt_location(202, 'quicksort.c', 24).
stmt_location(fun(214), 'quicksort.c', 20).
stmt_location(194, 'quicksort.c', 15).
stmt_location(180, 'quicksort.c', 5).
stmt_location(198, 'quicksort.c', 21).
stmt_location(197, 'quicksort.c', 21).
stmt_location(175, 'quicksort.c', 4).
stmt_location(187, 'quicksort.c', 9).
stmt_location(167, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(165, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(189, 'quicksort.c', 4).
stmt_location(n(3), 'quicksort.c', 4).
stmt_location(185, 'quicksort.c', 7).
stmt_location(193, 'quicksort.c', 14).
stmt_location(200, 'quicksort.c', 23).
stmt_location(184, 'quicksort.c', 6).
stmt_location(199, 'quicksort.c', 22).
stmt_location(191, 'quicksort.c', 12).
stmt_location(172, 'quicksort.c', 4).
