unsigned int rotateLeft(unsigned int n, int d) {
    return (d << n) | (n >> (32 - d));
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    unsigned int result = rotateLeft(arg1, arg2);
    return 0;
}
