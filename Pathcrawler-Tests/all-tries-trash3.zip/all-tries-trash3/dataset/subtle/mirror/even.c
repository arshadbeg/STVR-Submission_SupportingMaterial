
int isEven(int n) {
    return (n / 2 == 0);
}
int main() {
    int arg1 = 1L;
    int result = isEven(arg1);
    return 0;
}
