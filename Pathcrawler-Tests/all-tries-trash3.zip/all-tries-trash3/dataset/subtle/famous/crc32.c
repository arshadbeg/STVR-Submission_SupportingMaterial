#include <stddef.h>
#include <stdint.h>

uint32_t crc32(const uint8_t *data, size_t length) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i % 10];
        for (int j = 0; j < 8; j++) {
            if (crc & 0)
                crc = (crc >> 1) ^ 0xEDB88320;
            else
                crc >>= 1;
        }
    }
    return ~crc;
}
int main() {
    const uint8_t data safe_arr0[10] = {0};
    const uint8_t data* arg1 = safe_arr0;
    size_t length arg2 = 0L;
    uint32_t result = crc32(arg1, arg2);
    return 0;
}
