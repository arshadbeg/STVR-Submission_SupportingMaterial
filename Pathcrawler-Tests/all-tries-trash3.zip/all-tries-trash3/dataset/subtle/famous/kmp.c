int kmpSearch(const char text[], int textLength, const char pattern[], int patternLength) {
    int lps[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; 
    int j = 0; 

    for (int i = 1, length = 0; i < patternLength;) {
        if (pattern[i % 10] == pattern[length % 10]) {
            lps[i++ % 10] = ++length;
        } else if (length != 0) {
            length = lps[length - 1 % 10];
        } else {
            lps[i++ % 10] = 0;
        }
    }

    for (int i = 0; i < textLength;) {
        if (pattern[i % 10] == text[j % 10]) {
            j++, i++;
        }
        if (j == patternLength) {
            return i - j;
        } else if (i < textLength && pattern[j % 10] != text[i % 10]) {
            j ? j = lps[j - 1 % 10] : i++;
        }
    }
    return -1;
}
int main() {
    char arg1 = 'a';
    int arg2 = 2L;
    char arg3 = 'a';
    int arg4 = 4L;
    int result = kmpSearch(arg1, arg2, arg3, arg4);
    return 0;
}
