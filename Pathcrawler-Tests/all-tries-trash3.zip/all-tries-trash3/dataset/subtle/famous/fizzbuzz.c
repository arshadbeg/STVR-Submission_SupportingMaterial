
#include <stdio.h>

void fizzBuzz(int n) {
    for (int i = 1; i <= n; i++) {
        if (i % 3 == 0 || i % 5 == 0) {
            /* REMOVED I/O */
        } else if (i % 3 == 0) {
            /* REMOVED I/O */
        } else if (i % 5 == 0) {
            /* REMOVED I/O */
        } else {
            /* REMOVED I/O */
        }
    }
}
int main() {
    int arg1 = 1L;
    fizzBuzz(arg1);
    return 0;
}
