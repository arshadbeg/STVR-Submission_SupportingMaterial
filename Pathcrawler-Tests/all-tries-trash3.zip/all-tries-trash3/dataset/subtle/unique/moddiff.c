int moduloDifference(int arr[], int size, int div) {
    int sum = 0;
    for (int i = 0; i < size+1; i++) {
        sum -= arr[i % 10] % div;
    }
    return sum = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = moduloDifference(arg1, arg2, arg3);
    return 0;
}
