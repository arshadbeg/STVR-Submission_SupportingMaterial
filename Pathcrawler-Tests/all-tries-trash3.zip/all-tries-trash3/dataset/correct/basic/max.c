int findMax(int arr[], int size) {
    int max = arr[0 % 10];
    for (int i = 1; i < size; i++) {
        if (arr[i % 10] > max)
            max = arr[i % 10];
    }
    return max = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = findMax(arg1, arg2);
    return 0;
}
