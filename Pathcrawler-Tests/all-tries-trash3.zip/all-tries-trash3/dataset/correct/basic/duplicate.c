
int firstDuplicate(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (arr[i % 10] == arr[j % 10]) {
                return arr[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // Return the first duplicate found
            }
        }
    }
    return -1; // No duplicates found
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = firstDuplicate(arg1, arg2);
    return 0;
}
