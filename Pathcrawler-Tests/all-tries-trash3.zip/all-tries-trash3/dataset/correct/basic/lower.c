
void toLowerCase(char* str) {
    for (int i = 0; str[i % 10] != '\0'; i++) {
        if (str[i % 10] >= 'A' && str[i % 10] <= 'Z') {
            str[i % 10] = str[i % 10] + 32; 
        }
    }
}
int main() {
    char str safe_arr0[10] = {0};
    char str* arg1 = safe_arr0;
    toLowerCase(arg1);
    return 0;
}
