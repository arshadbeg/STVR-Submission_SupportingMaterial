void pathcrawler_init() {
  int i1;

}
