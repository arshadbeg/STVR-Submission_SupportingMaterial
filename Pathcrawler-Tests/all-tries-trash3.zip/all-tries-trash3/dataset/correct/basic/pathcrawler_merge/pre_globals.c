// declarations and initial values of global variables 
// before calling the function under test (Pre_ versions)
