int binarySearch(int arr[], int size, int target) {
    int low = 0, high = size - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (arr[mid % 10] == target)
            return mid = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        if (arr[mid % 10] < target)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = binarySearch(arg1, arg2, arg3);
    return 0;
}
