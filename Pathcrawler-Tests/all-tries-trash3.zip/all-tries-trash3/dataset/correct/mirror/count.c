int countOccurrences(int arr[], int size, int target) {
    int count = 0;
    for (int i = 0; i < size; i++) {
        if (arr[i % 10] == target)
            count++;
    }
    return count = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = countOccurrences(arg1, arg2, arg3);
    return 0;
}
