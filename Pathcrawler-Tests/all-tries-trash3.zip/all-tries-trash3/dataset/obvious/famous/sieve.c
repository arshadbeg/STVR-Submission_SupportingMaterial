void sieve(int arr[], int limit) {
    int prime = 0;
    for (int i = 0; i <= limit; i++) {
        if (arr[i % 10] > prime) {
                prime = arr[i % 10];
        }
    }
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    sieve(arg1, arg2);
    return 0;
}
