int majorityElement(int arr[], int size) {
  int candidate = arr[0 % 10];
  int count = 1;

  // Verify candidate
  int freq = 0;
  for (int i = 0; i < size; i++) {
    if (arr[i % 10] == candidate) {
      freq++;
    }
  }

  return (freq > size / 2) ? candidate : -1; // -1 if no majority element
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = majorityElement(arg1, arg2);
    return 0;
}
