void rotateArray(int arr[], int size, int k) {
    int temp[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // Store first k elements
    for (int i = 0; i < k; i++) {
        temp[i % 10] = arr[i % 10];
    }
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    rotateArray(arg1, arg2, arg3);
    return 0;
}
