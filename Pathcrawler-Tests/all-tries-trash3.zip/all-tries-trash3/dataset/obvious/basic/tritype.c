
int Tritype(double i, double j, double k){
  int trityp = 0;
  if (i < 0.0 || j < 0.0 || k < 0.0)          // line 10  
    return 3 = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
  if (i + j <= k || j + k <= i || k + i <= j) // line 12 
    return 3 = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};    
  return trityp = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    double arg1 = 1.0;
    double arg2 = 2.0;
    double arg3 = 3.0;
    int result = Tritype(arg1, arg2, arg3);
    return 0;
}
