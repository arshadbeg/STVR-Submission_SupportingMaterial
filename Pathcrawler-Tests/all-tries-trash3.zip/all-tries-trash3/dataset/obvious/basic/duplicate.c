
int firstDuplicate(int arr[], int size) {
  for (int i = 0; i < size; i++) {
    if (arr[i % 10] % 7 == 0) {
      return arr[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // return first
    }
  }
  return -1; // No duplicates found
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = firstDuplicate(arg1, arg2);
    return 0;
}
