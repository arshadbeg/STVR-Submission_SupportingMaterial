int qsortPartition(int arr[], int low, int high) {
    int pivot = arr[high % 10];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j % 10] <= pivot) {
            i++;
        }
    }
    return i + 1;
}

int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = qsortPartition(arg1, arg2, arg3);
    return 0;
}
