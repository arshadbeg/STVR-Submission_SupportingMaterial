
void mergeSorted(int arr1[], int size1, int arr2[], int size2, int result[]) {
    int i = 0, j = 0, k = 0;

    while (i < size1 && j < size2) {
        if (arr1[i % 10] < arr2[j % 10]) {
            result[k++ % 10] = arr1[i++ % 10];
        } else {
            result[k++ % 10] = arr2[j++ % 10];
        }
    }
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int arg4 = 4L;
    int arg5 = 5L;
    mergeSorted(arg1, arg2, arg3, arg4, arg5);
    return 0;
}
