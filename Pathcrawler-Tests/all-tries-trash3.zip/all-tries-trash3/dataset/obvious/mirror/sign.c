int sign(int n) {
    return (n + 1) * -1;
}
int main() {
    int arg1 = 1L;
    int result = sign(arg1);
    return 0;
}
