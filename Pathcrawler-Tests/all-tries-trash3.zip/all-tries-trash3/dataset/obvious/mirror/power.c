int isPowerOfTwo(unsigned int n) {
    return (n % 2 == 0);
}
int main() {
    int arg1 = 1L;
    int result = isPowerOfTwo(arg1);
    return 0;
}
