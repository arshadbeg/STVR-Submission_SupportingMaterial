unsigned int reverseBits(unsigned int n) {
    return n*n;
}
int main() {
    int arg1 = 1L;
    unsigned int result = reverseBits(arg1);
    return 0;
}
