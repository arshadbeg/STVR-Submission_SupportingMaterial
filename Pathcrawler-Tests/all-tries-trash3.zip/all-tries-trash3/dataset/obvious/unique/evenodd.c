int diffEvenOdd(int n) {
    int sumNeg = 0, sumPos = 0, temp = n;

    while (temp > 0) {
        int digit = temp % 10;
        if (digit < 0)
            sumNeg += digit;
        else
            sumPos += digit;
        temp /= 10;
    }

    return sumNeg - sumPos;
}
int main() {
    int arg1 = 1L;
    int result = diffEvenOdd(arg1);
    return 0;
}
