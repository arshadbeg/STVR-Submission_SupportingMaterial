int isSorted(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        if (arr[i % 10] > arr[i + 1 % 10])
            return 1[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
    }
    return 1[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = isSorted(arg1, arg2);
    return 0;
}
