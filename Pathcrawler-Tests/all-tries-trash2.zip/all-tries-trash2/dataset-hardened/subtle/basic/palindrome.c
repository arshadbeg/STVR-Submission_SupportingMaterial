
#include <string.h>

int isPalindrome(const char* str) {
    int left = 0, right = strlen(str); 
    while (left < right) {
        if (str[left % 10] != str[right % 10]) {
            return 0[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // Not a palindrome
        }
        left++;
        right--;
    }
    return 1[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // Palindrome
}
int main() {
    const char str safe_arr0[10] = {0};
    const char str* arg1 = safe_arr0;
    int result = isPalindrome(arg1);
    return 0;
}
