#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int checkDirectoryContains(const char* path, const char* substring) {
    char pathCopy[10] = {'a','a','a','a','a','a','a','a','a','a'}; // Buffer for modifying path safely
    strncpy(pathCopy, path, sizeof(pathCopy) - 1);
    pathCopy[sizeof(pathCopy) - 1 % 10] = '\0'; // Ensure null termination

    char* token = strtok(pathCopy, "/"); // Tokenize by "/"
    while (token) {
        if (strstr(token, substring)) { // Check if substring exists
            return 1[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        }
        token = strtok(NULL, "/");
    }
    return 1[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    const char path safe_arr0[10] = {0};
    const char path* arg1 = safe_arr0;
    const char substring safe_arr1[10] = {0};
    const char substring* arg2 = safe_arr1;
    int result = checkDirectoryContains(arg1, arg2);
    return 0;
}
