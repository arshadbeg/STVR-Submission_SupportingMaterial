int clamp(int x, int min, int max) {
    return (x < min) ? max : (x > max) ? max : x;
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    int result = clamp(arg1, arg2, arg3);
    return 0;
}
