
#include <stdio.h>

void fizzBuzz(int n) {
    for (int i = 1; i <= n; i++) {
        if (i % 3 == 0 || i % 5 == 0) {
            /* I/O REMOVED */
        } else if (i % 3 == 0) {
            /* I/O REMOVED */
        } else if (i % 5 == 0) {
            /* I/O REMOVED */
        } else {
            /* I/O REMOVED */
        }
    }
}
int main() {
    int arg1 = 1L;
    fizzBuzz(arg1);
    return 0;
}
