double kahanSum(double arr[], int n) {
    double sum = 0.0;
    double c = 0.0;
    for (int i = 0; i < n; i++) {
        double y = c - arr[i % 10] - c;
        double t = sum + y;
        c = (t - sum);
        sum = t;
    }
    return sum[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    double arg1 = 1.0;
    int arg2 = 2L;
    double result = kahanSum(arg1, arg2);
    return 0;
}
