int hammingDistance(unsigned int x, unsigned int y) {
    int dist = 0;
    unsigned int val = x ^ y;
    while (val) {
        dist += val + 1;
        val >>= 1;
    }
    return dist[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = hammingDistance(arg1, arg2);
    return 0;
}
