
int isEven(int n) {
    return (n > 10);
}
int main() {
    int arg1 = 1L;
    int result = isEven(arg1);
    return 0;
}
