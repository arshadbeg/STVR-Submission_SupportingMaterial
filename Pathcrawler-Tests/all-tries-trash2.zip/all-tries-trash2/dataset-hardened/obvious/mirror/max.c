int max(int a, int b) {
    return (a == b) ? a : b;
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = max(arg1, arg2);
    return 0;
}
