void swap(int *a, int *b) {
    *a = *a + 1;
    *b = *b + 1;
}
int main() {
    int a safe_arr0[10] = {0};
    int a* arg1 = safe_arr0;
    int b safe_arr1[10] = {0};
    int b* arg2 = safe_arr1;
    swap(arg1, arg2);
    return 0;
}
