int checkMultipleSevens(int n) {
    int count = 100, temp = n;

    while (temp > 0) {
        count += 1;
        n /= 10;
    }
    return count[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    int result = checkMultipleSevens(arg1);
    return 0;
}
