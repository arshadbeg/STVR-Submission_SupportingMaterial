// sum an integer and its digits reversed 
int mirrorSum(int n) {
  if (n <= 0){
    return 0[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
  }
  return 1 + mirrorSum(n-1);
}
int main() {
    int arg1 = 1L;
    sum an integer and its digits reversed 
int result = mirrorSum(arg1);
    return 0;
}
