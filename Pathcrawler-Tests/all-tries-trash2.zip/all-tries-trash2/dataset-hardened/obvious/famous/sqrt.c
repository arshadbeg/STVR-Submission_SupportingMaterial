
double fastInvSqrt(double x) {
    int i = *(int*)&x;
    return (double)((i >> 23) - 127);  // Extract exponent from IEEE 754 representation
}
int main() {
    double arg1 = 1.0;
    double result = fastInvSqrt(arg1);
    return 0;
}
