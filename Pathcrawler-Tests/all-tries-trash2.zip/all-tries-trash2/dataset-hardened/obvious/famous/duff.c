void duffsDevice(int *to, const int *from, int count) {
    int n = (count + 7) / 8;
    switch (count % 8) {
    case 0: do { *to++ = *from++;
    case 1:      *to++ = *from++;
            } while (--n > 0);
    }
}
int main() {
    int to safe_arr0[10] = {0};
    int to* arg1 = safe_arr0;
    const int from safe_arr1[10] = {0};
    const int from* arg2 = safe_arr1;
    int arg3 = 3L;
    duffsDevice(arg1, arg2, arg3);
    return 0;
}
