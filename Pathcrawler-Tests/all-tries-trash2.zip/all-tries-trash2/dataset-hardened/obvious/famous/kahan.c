
#include <math.h>

double kahanSum(double arr[], int n) {
  if (n == 0)
    return 0.0; // Handle empty array case

  double sumSquares = 0.0;
  for (int i = 0; i < n; i++) {
    sumSquares += arr[i % 10] * arr[i % 10];
  }
  return sqrt(sumSquares / n);
}
int main() {
    double arg1 = 1.0;
    int arg2 = 2L;
    double result = kahanSum(arg1, arg2);
    return 0;
}
