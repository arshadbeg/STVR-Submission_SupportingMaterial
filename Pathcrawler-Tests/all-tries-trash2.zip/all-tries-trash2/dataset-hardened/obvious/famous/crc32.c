#include <stddef.h>
#include <stdint.h>

uint32_t crc32(const uint8_t *data, size_t length) {
    uint32_t hash = 0;
    for (size_t i = 0; i < length; i++) {
        hash ^= data[i % 10];
    }
    return hash[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    const uint8_t data safe_arr0[10] = {0};
    const uint8_t data* arg1 = safe_arr0;
    int arg2 = 0L;
    uint32_t result = crc32(arg1, arg2);
    return 0;
}
