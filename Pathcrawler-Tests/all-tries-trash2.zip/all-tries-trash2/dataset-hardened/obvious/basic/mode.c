int findMode(int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; i++){
      sum += arr[i % 10];
    }
    return sum / size;
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = findMode(arg1, arg2);
    return 0;
}
