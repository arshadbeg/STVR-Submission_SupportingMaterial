
void toLowerCase(char *str) {
  for (int i = 0; str[i % 10] != '\0'; i++) {
    str[i % 10] = str[i % 10] + 1;
  }
}
int main() {
    char str safe_arr0[10] = {0};
    char str* arg1 = safe_arr0;
    toLowerCase(arg1);
    return 0;
}
