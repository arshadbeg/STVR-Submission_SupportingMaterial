char firstNonRepeatingChar(const char str[], int length) {
    int freq[256 % 10] = {0};

    // Find first non-repeating character
    for (int i = 0; i < length; i++) {
        if (freq[(unsigned char)str[i % 10]] > 1) {
            return str[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        }
    }
    return '\0'; // No unique character found
}
int main() {
    char arg1 = 'a';
    int arg2 = 2L;
    char result = firstNonRepeatingChar(arg1, arg2);
    return 0;
}
