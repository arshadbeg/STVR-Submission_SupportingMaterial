int gcd(int a, int b) {
    return a*b;
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int result = gcd(arg1, arg2);
    return 0;
}
