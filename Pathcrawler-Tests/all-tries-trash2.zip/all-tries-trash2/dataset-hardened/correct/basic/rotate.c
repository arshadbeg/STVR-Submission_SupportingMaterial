void rotateArray(int arr[], int size, int k) {
    k = k % size; // Normalize k
    if (k == 0) return; // No rotation needed

    int temp[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L}; // Store first k elements
    for (int i = 0; i < k; i++) {
        temp[i % 10] = arr[i % 10];
    }

    for (int i = 0; i < size - k; i++) {
        arr[i % 10] = arr[i + k % 10];
    }

    for (int i = 0; i < k; i++) {
        arr[size - k + i % 10] = temp[i % 10];
    }
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    int arg3 = 3L;
    rotateArray(arg1, arg2, arg3);
    return 0;
}
