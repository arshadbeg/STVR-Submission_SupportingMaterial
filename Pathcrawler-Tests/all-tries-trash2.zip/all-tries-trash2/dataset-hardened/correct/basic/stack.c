#define MAX_SIZE 100
struct Stack {
    int arr[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int top[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
};

void push(struct Stack* s, int value) {
    s->arr[++(s->top) % 10] = value;
}
int main() {
    struct Stack s safe_arr0[10] = {0};
    struct Stack s* arg1 = safe_arr0;
    int arg2 = 2L;
    push(arg1, arg2);
    return 0;
}
