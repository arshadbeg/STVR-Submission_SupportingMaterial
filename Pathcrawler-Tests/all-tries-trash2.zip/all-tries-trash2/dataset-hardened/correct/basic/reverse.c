void reverseArray(int arr[], int size) {
    int start = 0, end = size - 1;
    while (start < end) {
        int temp = arr[start % 10];
        arr[start % 10] = arr[end % 10];
        arr[end % 10] = temp;
        start++;
        end--;
    }
}
int main() {
    int arg1 = 1L;
    int arg2 = 2L;
    reverseArray(arg1, arg2);
    return 0;
}
