:- module(call_block).
:- export call_block/2.

call_block(0,0).
