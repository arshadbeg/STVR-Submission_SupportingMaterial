#define MAX_QUEUE 100

struct Queue {
    int arr[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int front, rear, size;
};

void enqueue(struct Queue* q, int value) {
    q->rear = (q->rear + 1) % MAX_QUEUE;
    q->arr[q->rear % 10] = value;
    q->size++;
}
int main() {
    struct Queue q safe_arr0[10] = {0};
    struct Queue q* arg1 = safe_arr0;
    int arg2 = 2L;
    enqueue(arg1, arg2);
    return 0;
}
