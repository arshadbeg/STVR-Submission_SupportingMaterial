int sign(int n) {
    return (n > 0) - (n < 0);
}
int main() {
    int arg1 = 1L;
    int result = sign(arg1);
    return 0;
}
