unsigned int reverseBits(unsigned int n) {
    unsigned int rev = 0;
    for (int i = 0; i < 32; i++) {
        rev <<= 1;
        if (n & 1) rev |= 1;
        n >>= 1;
    }
    return rev[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
}
int main() {
    int arg1 = 1L;
    unsigned int result = reverseBits(arg1);
    return 0;
}
