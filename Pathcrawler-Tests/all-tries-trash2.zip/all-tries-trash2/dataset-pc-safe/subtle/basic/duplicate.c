/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */


int firstDuplicate(int arr[], int size) {    /* PATHCRAWLER SAFETY: local buffer for pointer param size */
    int __pc_safe_size_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_size_buf[__pc_i] = (int)0;
    (void)__pc_safe_size_buf;

    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (arr[i % 10] == arr[j % 10]) {
                return arr[j % 10]; // Return the first duplicate found
            }
        }
    }
    return -1; // No duplicates found
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int size) {
    /* injected branching to give PathCrawler paths */
    if (size == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


int firstDuplicate(int arr[], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


int firstDuplicate(int arr[], int* size = __pc_safe_arr_0;
    __pc_wrapper_malloc(size);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
