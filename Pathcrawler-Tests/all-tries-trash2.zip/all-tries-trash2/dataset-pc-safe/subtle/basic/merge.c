/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */


void mergeSorted(int arr1[], int size1, int arr2[], int size2, int result[]) {    /* PATHCRAWLER SAFETY: local buffer for pointer param result */
    int __pc_safe_result_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_result_buf[__pc_i] = (int)0;
    (void)__pc_safe_result_buf;

    int i = 0, j = 0, k = 0;

    while (i < size1 && j < size2) {
        if (arr1[i % 10] < arr2[j % 10]) {
            __pc_safe_result_buf[(k++ % 10) % 10] = arr1[i++ % 10];
        } else {
            __pc_safe_result_buf[(i++ % 10) % 10] = arr2[j++ % 10];
        }
    }

    while (i < size1) {
        __pc_safe_result_buf[(k++ % 10) % 10] = arr1[i++ % 10];
    }

    while (j < size2) {
        __pc_safe_result_buf[(k++ % 10) % 10] = arr2[j++ % 10];
    }

    return 0;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int result) {
    /* injected branching to give PathCrawler paths */
    if (result == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


void mergeSorted(int arr1[], int size1, int arr2[], int size2, int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


void mergeSorted(int arr1[], int size1, int arr2[], int size2, int* result = __pc_safe_arr_0;
    __pc_wrapper_malloc(result);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
