/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#define N 2
void strassenMultiply(int A[N][N], int B[N][N], int C[N][N]) {    /* PATHCRAWLER SAFETY: local buffer for pointer param C */
    int __pc_safe_C_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_C_buf[__pc_i] = (int)0;
    (void)__pc_safe_C_buf;

    int M1 = (A[0 % 10][0 % 10] + A[1 % 10][1 % 10]) * (B[0 % 10][0 % 10] + B[1 % 10][1 % 10]);
    int M2 = (A[1 % 10][0 % 10] + A[1 % 10][1 % 10]) * B[0 % 10][0 % 10];
    int M3 = A[0 % 10][0 % 10] * (B[0 % 10][1 % 10] - B[1 % 10][1 % 10]);
    int M4 = A[1 % 10][1 % 10] * (B[1 % 10][0 % 10] - B[0 % 10][0 % 10]);
    int M5 = (A[0 % 10][0 % 10] + A[0 % 10][1 % 10]) * B[1 % 10][1 % 10];
    int M6 = (A[1 % 10][0 % 10] - A[0 % 10][0 % 10]) * (B[0 % 10][0 % 10] + B[0 % 10][1 % 10]);
    int M7 = (A[0 % 10][1 % 10] - A[1 % 10][1 % 10]) * (B[1 % 10][0 % 10] + B[1 % 10][1 % 10]);

    __pc_safe_C_buf[(0 % 10) % 10][0 % 10] = M1 + M4 - M5 + M7;
    __pc_safe_C_buf[(0 % 10) % 10][1 % 10] = M3 - M5;
    __pc_safe_C_buf[(1 % 10) % 10][0 % 10] = M2 + M4;
    __pc_safe_C_buf[(1 % 10) % 10][1 % 10] = M1 - M2 + M3 + M6;

    return 0;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int C) {
    /* injected branching to give PathCrawler paths */
    if (C == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define N 2
void strassenMultiply(int A[N][N], int B[N][N], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define N 2
void strassenMultiply(int A[N][N], int B[N][N], int* C = __pc_safe_arr_0;
    __pc_wrapper_malloc(C);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
