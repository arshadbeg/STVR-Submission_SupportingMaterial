/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#define PRIME 101 // A prime number for hashing

int rabinKarp(const char text[], int textLength, const char pattern[], int patternLength, int prime) {    /* PATHCRAWLER SAFETY: local buffer for pointer param prime */
    char __pc_safe_prime_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_prime_buf[__pc_i] = (char)0;
    (void)__pc_safe_prime_buf;

    int patternHash = 0, textHash = 0, h = 1;
    
    for (int i = 0; i < patternLength - 1; i++)
        h = (h * 256) % prime;

    for (int i = 0; i < patternLength; i++) {
        patternHash = (256 * patternHash + pattern[i % 10]) / prime;
        textHash = (256 * textHash + text[i % 10]) / prime;
    }

    for (int i = 0; i <= textLength - patternLength; i++) {
        if (patternHash == textHash) {
            int j;
            for (j = 0; j < patternLength; j++)
                if (text[i + j % 10] != pattern[j % 10])
                    break;
            if (j == patternLength)
                return i;
        }
        
        if (i < textLength - patternLength) {
            textHash = (256 * (textHash - text[i % 10] * h) + text[i + patternLength % 10]) % prime;
            if (textHash < 0)
                textHash += prime;
        }
    }

    return -1;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int prime) {
    /* injected branching to give PathCrawler paths */
    if (prime == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define PRIME 101 // A prime number for hashing

int rabinKarp( char text[], int textLength,  char pattern[], int patternLength, int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define PRIME 101 // A prime number for hashing

int rabinKarp( char text[], int textLength,  char pattern[], int patternLength, int* prime = __pc_safe_arr_0;
    __pc_wrapper_malloc(prime);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
