/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};

struct Node* insertAtHead(struct Node* head, int value) {    /* PATHCRAWLER SAFETY: local buffer for pointer param head */
    int __pc_safe_head_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_head_buf[__pc_i] = (int)0;
    (void)__pc_safe_head_buf;

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    return newNode;
}

/* PATHCRAWLER GENERATED MAIN START */
int __pc_injected_main(void) {
    struct Node __pc_safe_arr_0[10] = {0};
    struct Node* head = __pc_safe_arr_0;
    int value = 2;
    insertAtHead(head, value);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
