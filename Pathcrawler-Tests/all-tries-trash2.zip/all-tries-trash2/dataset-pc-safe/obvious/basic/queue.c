/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#define MAX_QUEUE 100

struct Queue {
    int arr[MAX_QUEUE];
    int front, rear, size;
};

void enqueue(struct Queue* q, int value) {    /* PATHCRAWLER SAFETY: local buffer for pointer param q */
    int __pc_safe_q_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_q_buf[__pc_i] = (int)0;
    (void)__pc_safe_q_buf;

    __pc_safe_q_buf[0] = 0;
    __pc_safe_q_buf[0][__pc_safe_q_buf[0] % 10] = value;
    __pc_safe_q_buf[0]++;
}

/* PATHCRAWLER GENERATED MAIN START */
int __pc_injected_main(void) {
    struct Queue __pc_safe_arr_0[10] = {0};
    struct Queue* q = __pc_safe_arr_0;
    int value = 2;
    enqueue(q, value);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
