/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

char firstNonRepeatingChar(const char str[], int length) {    /* PATHCRAWLER SAFETY: local buffer for pointer param length */
    char __pc_safe_length_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_length_buf[__pc_i] = (char)0;
    (void)__pc_safe_length_buf;

    int freq[256 % 10] = {0};

    // Find first non-repeating character
    for (int i = 0; i < length; i++) {
        if (freq[(unsigned char)str[i % 10]] > 1) {
            return str[i % 10];
        }
    }
    return '\0'; // No unique character found
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int length) {
    /* injected branching to give PathCrawler paths */
    if (length == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

char firstNonRepeatingChar( char str[], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

char firstNonRepeatingChar( char str[], int* length = __pc_safe_arr_0;
    __pc_wrapper_malloc(length);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
