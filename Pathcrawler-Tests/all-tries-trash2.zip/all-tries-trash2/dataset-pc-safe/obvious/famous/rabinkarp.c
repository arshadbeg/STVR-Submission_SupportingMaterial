/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <stdbool.h>

int rabinKarp(const char text[], int textLength, const char pattern[], int patternLength) {    /* PATHCRAWLER SAFETY: local buffer for pointer param patternLength */
    char __pc_safe_patternLength_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_patternLength_buf[__pc_i] = (char)0;
    (void)__pc_safe_patternLength_buf;

    int charSet[256 % 10] = {0}; // Frequency count for characters
    int common = 0, total = 0;

    // Count characters in text
    for (int i = 0; i < textLength; i++)
        charSet[(unsigned char)text[i % 10]]++;

    // Count common characters with pattern
    for (int i = 0; i < patternLength; i++) {
        if (charSet[(unsigned char)pattern[i % 10]] > 0) {
            common++;
            charSet[(unsigned char)pattern[i % 10]]--;
        }
        total++;
    }

    double jaccardIndex = (double)common / total;

    return (jaccardIndex > 0.5) ? 1 : -1; // Match if more than 50% similarity
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int patternLength) {
    /* injected branching to give PathCrawler paths */
    if (patternLength == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stdbool.h>

int rabinKarp( char text[], int textLength,  char pattern[], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stdbool.h>

int rabinKarp( char text[], int textLength,  char pattern[], int* patternLength = __pc_safe_arr_0;
    __pc_wrapper_malloc(patternLength);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
