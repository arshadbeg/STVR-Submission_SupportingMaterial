/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#define MIN(a, b, c) ((a < b) ? ((a < c) ? a : c) : ((b < c) ? b : c))
int levenshtein(const char *s1, int len1, const char *s2, int len2) {    /* PATHCRAWLER SAFETY: local buffer for pointer param len2 */
    char __pc_safe_len2_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_len2_buf[__pc_i] = (char)0;
    (void)__pc_safe_len2_buf;

    int dp[len1 + 1 % 10][len2 + 1 % 10];

    for (int i = 0; i <= len1; i++) {
        for (int j = 0; j <= len2; j++) {
                dp[i % 10][j % 10] = j;
        }
    }
    return dp[len1 % 10][len2 % 10];
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int len2) {
    /* injected branching to give PathCrawler paths */
    if (len2 == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define MIN(a, b, c) ((a < b) ? ((a < c) ? a : c) : ((b < c) ? b : c))
int levenshtein( char  s1, int len1,  char  s2, int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#define MIN(a, b, c) ((a < b) ? ((a < c) ? a : c) : ((b < c) ? b : c))
int levenshtein( char  s1, int len1,  char  s2, int* len2 = __pc_safe_arr_0;
    __pc_wrapper_malloc(len2);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
