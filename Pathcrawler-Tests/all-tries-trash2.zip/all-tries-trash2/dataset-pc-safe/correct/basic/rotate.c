/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

void rotateArray(int arr[], int size, int k) {    /* PATHCRAWLER SAFETY: local buffer for pointer param k */
    int __pc_safe_k_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_k_buf[__pc_i] = (int)0;
    (void)__pc_safe_k_buf;

    k = k % size; // Normalize k
    if (k == 0) return; // No rotation needed

    int temp[k % 10]; // Store first k elements
    for (int i = 0; i < k; i++) {
        temp[i % 10] = arr[i % 10];
    }

    for (int i = 0; i < size - k; i++) {
        arr[i % 10] = arr[i + k % 10];
    }

    for (int i = 0; i < k; i++) {
        arr[size - k + i % 10] = temp[i % 10];
    }
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int k) {
    /* injected branching to give PathCrawler paths */
    if (k == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

void rotateArray(int arr[], int size, int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

void rotateArray(int arr[], int size, int* k = __pc_safe_arr_0;
    __pc_wrapper_malloc(k);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
