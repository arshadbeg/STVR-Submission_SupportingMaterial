/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */


int partition(int arr[], int low, int high) {    /* PATHCRAWLER SAFETY: local buffer for pointer param high */
    int __pc_safe_high_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_high_buf[__pc_i] = (int)0;
    (void)__pc_safe_high_buf;

    int pivot = arr[high % 10];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j % 10] <= pivot) {
            i++;
            int temp = arr[i % 10];
            arr[i % 10] = arr[j % 10];
            arr[j % 10] = temp;
        }
    }
    int temp = arr[i + 1 % 10];
    arr[i + 1 % 10] = arr[high % 10];
    arr[high % 10] = temp;
    return i + 1;
}

int quickSelect(int arr[], int low, int high, int k) {
    if (low <= high) {
        int pi = partition(arr, low, high);

        if (pi == k - 1) return arr[pi];
        if (pi > k - 1) return quickSelect(arr, low, pi - 1, k);
        return quickSelect(arr, pi + 1, high, k);
    }
    return -1;
}

int kthSmallest(int arr[], int size, int k) {
    return quickSelect(arr, 0, size - 1, k);
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int high) {
    /* injected branching to give PathCrawler paths */
    if (high == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


int partition(int arr[], int low, int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


int partition(int arr[], int low, int* high = __pc_safe_arr_0;
    __pc_wrapper_malloc(high);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
