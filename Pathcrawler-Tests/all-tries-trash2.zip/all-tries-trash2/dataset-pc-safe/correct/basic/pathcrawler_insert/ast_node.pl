:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(1), for, [cond(atomic_cond(n(4))),body(n(2)),action(n(3))]). % insert.c: l.17
ast_node(n(2), seq, [154]). % insert.c: l.17
ast_node(147, assign, ['__pc_i', c(0,i(si(4)))]). % insert.c: l.17
ast_node(169, return, ['__retres']). % insert.c: l.32
ast_node(146, seq, [147,n(1),157,158,159,160,161]). % insert.c: l.17
ast_node(160, assign, [f(e('newNode',c(0,i(si(4)))),'next'), 'head']). % insert.c: l.22
ast_node(171, seq, [172,173]). % insert.c: l.35
ast_node(168, assign, ['__retres', c(0,i(si(4)))]). % insert.c: l.32
ast_node(158, assign, ['newNode', cast(p(user(4)),'__pc_global_buf')]). % insert.c: l.20
ast_node(157, assign, ['tmp', '__pc_safe_head_buf']). % insert.c: l.18
ast_node(154, assign, [e('__pc_safe_head_buf','__pc_i'), c(0,i(si(4)))]). % insert.c: l.17
ast_node(fun(213), func, ['main', 0, 0, 1, 171]). % insert.c: l.35
ast_node(144, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(142, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(155, assign, ['__pc_i', +(i(si(4)),'__pc_i',c(1,i(si(4))))]). % insert.c: l.17
ast_node(161, return, ['newNode']). % insert.c: l.23
ast_node(167, call, ['insertAtHead', 'head', 'value']). % insert.c: l.31
ast_node(165, assign, ['head', '__pc_safe_arr_0']). % insert.c: l.29
ast_node(150, cond, [inf, '__pc_i', c(10,i(si(4)))]). % insert.c: l.17
ast_node(163, seq, [164,165,166,167,168,169]). % insert.c: l.28
ast_node(n(3), seq, [155]). % insert.c: l.17
ast_node(fun(189), func, ['__FC_assert', 4, 0, 0, 142]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(fun(208), func, ['__pc_injected_main', 0, 0, 1, 163]). % insert.c: l.27
ast_node(159, assign, [f(e('newNode',c(0,i(si(4)))),'data'), 'value']). % insert.c: l.21
ast_node(fun(199), func, ['insertAtHead', 2, 0, 1, 146]). % insert.c: l.15
ast_node(172, rescall, ['__pc_injected_main', '__tmp_lin_0']). % insert.c: l.35
ast_node(166, assign, ['value', c(2,i(si(4)))]). % insert.c: l.30
ast_node(173, return, ['__tmp_lin_0']). % insert.c: l.35
ast_node(i(2), assign, [f(e('__pc_safe_arr_0',c(0,i(si(4)))),'next'), cast(p(user(4)),c(0,i(si(4))))]). % insert.c: l.28
ast_node(164, seq, [i(1),i(2)]). % insert.c: l.28
ast_node(i(1), assign, [f(e('__pc_safe_arr_0',c(0,i(si(4)))),'data'), c(0,i(si(4)))]). % insert.c: l.28
atomic_cond(n(4), [empty, 150]).
stmt_location(n(1), 'insert.c', 17).
stmt_location(n(2), 'insert.c', 17).
stmt_location(147, 'insert.c', 17).
stmt_location(169, 'insert.c', 32).
stmt_location(146, 'insert.c', 17).
stmt_location(160, 'insert.c', 22).
stmt_location(171, 'insert.c', 35).
stmt_location(168, 'insert.c', 32).
stmt_location(158, 'insert.c', 20).
stmt_location(157, 'insert.c', 18).
stmt_location(154, 'insert.c', 17).
stmt_location(fun(213), 'insert.c', 35).
stmt_location(144, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(142, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(155, 'insert.c', 17).
stmt_location(161, 'insert.c', 23).
stmt_location(167, 'insert.c', 31).
stmt_location(165, 'insert.c', 29).
stmt_location(150, 'insert.c', 17).
stmt_location(163, 'insert.c', 28).
stmt_location(n(3), 'insert.c', 17).
stmt_location(fun(189), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(fun(208), 'insert.c', 27).
stmt_location(159, 'insert.c', 21).
stmt_location(fun(199), 'insert.c', 15).
stmt_location(172, 'insert.c', 35).
stmt_location(166, 'insert.c', 30).
stmt_location(173, 'insert.c', 35).
stmt_location(i(2), 'insert.c', 28).
stmt_location(164, 'insert.c', 28).
stmt_location(i(1), 'insert.c', 28).
