:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(147, assign, ['__pc_i', c(0, i(si(4)))]).
ast_node(146, seq, [147, n(1), 157, 158, 159, 160, 161]).
ast_node(160, assign, [f(e(newNode, c(0, i(si(4)))), next), head]).
ast_node(171, seq, [172, 173]).
ast_node(158, assign, [newNode, cast(p(user(4)), '__pc_global_buf')]).
ast_node(157, assign, [tmp, '__pc_safe_head_buf']).
ast_node(154, assign, [e('__pc_safe_head_buf', '__pc_i'), c(0, i(si(4)))]).
ast_node(fun(213), func, [main, 0, 0, 1, 171]).
ast_node(155, assign, ['__pc_i', +(i(si(4)), '__pc_i', c(1, i(si(4))))]).
ast_node(167, call, [insertAtHead, head, value]).
ast_node(165, assign, [head, '__pc_safe_arr_0']).
ast_node(150, cond, [inf, '__pc_i', c(10, i(si(4)))]).
ast_node(fun(208), func, ['__pc_injected_main', 0, 0, 1, 163]).
ast_node(159, assign, [f(e(newNode, c(0, i(si(4)))), data), value]).
ast_node(fun(199), func, [insertAtHead, 2, 0, 1, 146]).
ast_node(172, rescall, ['__pc_injected_main', '__tmp_lin_0']).
ast_node(166, assign, [value, c(2, i(si(4)))]).
ast_node(i(2), assign, [f(e('__pc_safe_arr_0', c(0, i(si(4)))), next), cast(p(user(4)), c(0, i(si(4))))]).
ast_node(164, seq, [i(1), i(2)]).
ast_node(i(1), assign, [f(e('__pc_safe_arr_0', c(0, i(si(4)))), data), c(0, i(si(4)))]).
ast_node(n(1), for, [150, 154, 155]).
ast_node(168, setres, [c(0, i(si(4)))]).
ast_node(fun(189), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(163, seq, [164, 165, 166, 167, 168]).
ast_node(161, setres, [newNode]).
ast_node(173, setres, ['__tmp_lin_0']).
ast_supernode(171, fun(213), 0, fun(213)).
ast_supernode(163, fun(208), 0, fun(208)).
ast_supernode(146, fun(199), 0, fun(199)).
ast_supernode(n(1), 146, 1, fun(199)).
ast_supernode(147, 146, 0, fun(199)).
ast_supernode(164, 163, 0, fun(208)).
ast_supernode(i(1), 164, 0, fun(208)).
ast_supernode(i(2), 164, 1, fun(208)).
ast_supernode(154, n(1), body, fun(199)).
ast_supernode(155, n(1), action, fun(199)).
ast_supernode(172, 171, 0, fun(213)).
ast_supernode(157, 146, 2, fun(199)).
ast_supernode(158, 146, 3, fun(199)).
ast_supernode(159, 146, 4, fun(199)).
ast_supernode(160, 146, 5, fun(199)).
ast_supernode(161, 146, 6, fun(199)).
ast_supernode(173, 171, 1, fun(213)).
ast_supernode(165, 163, 1, fun(208)).
ast_supernode(166, 163, 2, fun(208)).
ast_supernode(167, 163, 3, fun(208)).
ast_supernode(168, 163, 4, fun(208)).
ast_supernode(150, n(1), cond, fun(199)).
topleveldec(150, n(1), [150]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(150, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(1), 'insert.c', 17, 0).
stmt_location(146, 'insert.c', 17, 1).
stmt_location(160, 'insert.c', 22, 0).
stmt_location(171, 'insert.c', 35, 0).
stmt_location(168, 'insert.c', 32, 0).
stmt_location(158, 'insert.c', 20, 0).
stmt_location(157, 'insert.c', 18, 0).
stmt_location(147, 'insert.c', 17, 1).
stmt_location(fun(213), 'insert.c', 35, 0).
stmt_location(155, 'insert.c', 17, 2).
stmt_location(154, 'insert.c', 17, 3).
stmt_location(161, 'insert.c', 23, 0).
stmt_location(167, 'insert.c', 31, 0).
stmt_location(165, 'insert.c', 29, 0).
stmt_location(150, 'insert.c', 17, 0).
stmt_location(fun(189), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(fun(208), 'insert.c', 27, 0).
stmt_location(159, 'insert.c', 21, 0).
stmt_location(fun(199), 'insert.c', 15, 0).
stmt_location(172, 'insert.c', 35, 0).
stmt_location(166, 'insert.c', 30, 0).
stmt_location(173, 'insert.c', 35, 0).
stmt_location(163, 'insert.c', 28, 1).
stmt_location(164, 'insert.c', 28, 2).
stmt_location(i(1), 'insert.c', 28, 1).
stmt_location(i(2), 'insert.c', 28, 2).
