/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */


#include <string.h>

int isPalindrome(const char* str) {    /* PATHCRAWLER SAFETY: local buffer for pointer param str */
    char __pc_safe_str_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_str_buf[__pc_i] = (char)0;
    (void)__pc_safe_str_buf;

    int left = 0, right = strlen(str) - 1;
    while (left < right) {
        if (__pc_safe_str_buf[(left % 10) % 10] != __pc_safe_str_buf[(right % 10) % 10]) {
            return 0; // Not a palindrome
        }
        left++;
        right--;
    }
    return 1; // Palindrome
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int str) {
    /* injected branching to give PathCrawler paths */
    if (str == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


#include <string.h>

int isPalindrome( char __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /


#include <string.h>

int isPalindrome( char* str = __pc_safe_arr_0;
    __pc_wrapper_malloc(str);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
