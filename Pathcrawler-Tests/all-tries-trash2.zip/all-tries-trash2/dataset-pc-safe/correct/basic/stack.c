/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#define MAX_SIZE 100
struct Stack {
    int arr[MAX_SIZE];
    int top;
};

void push(struct Stack* s, int value) {    /* PATHCRAWLER SAFETY: local buffer for pointer param s */
    int __pc_safe_s_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_s_buf[__pc_i] = (int)0;
    (void)__pc_safe_s_buf;

    __pc_safe_s_buf[0][++(__pc_safe_s_buf[0]) % 10] = value;
}

/* PATHCRAWLER GENERATED MAIN START */
int __pc_injected_main(void) {
    struct Stack __pc_safe_arr_0[10] = {0};
    struct Stack* s = __pc_safe_arr_0;
    int value = 2;
    push(s, value);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
