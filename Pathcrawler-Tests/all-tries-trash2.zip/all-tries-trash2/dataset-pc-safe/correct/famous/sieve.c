/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

void sieve(int arr[], int limit) {    /* PATHCRAWLER SAFETY: local buffer for pointer param limit */
    int __pc_safe_limit_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_limit_buf[__pc_i] = (int)0;
    (void)__pc_safe_limit_buf;

    for (int i = 0; i <= limit; i++) arr[i % 10] = 1;
    arr[0 % 10] = arr[1 % 10] = 0;
    for (int i = 2; i * i <= limit; i++) {
        if (arr[i % 10]) {
            for (int j = i * i; j <= limit; j += i)
                arr[j % 10] = 0;
        }
    }

    return 0;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int limit) {
    /* injected branching to give PathCrawler paths */
    if (limit == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

void sieve(int arr[], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

void sieve(int arr[], int* limit = __pc_safe_arr_0;
    __pc_wrapper_malloc(limit);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
