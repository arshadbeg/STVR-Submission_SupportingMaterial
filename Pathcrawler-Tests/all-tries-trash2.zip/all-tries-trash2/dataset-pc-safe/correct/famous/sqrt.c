/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

float fastInvSqrt(float x) {    /* PATHCRAWLER SAFETY: local buffer for pointer param x */
    int __pc_safe_x_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_x_buf[__pc_i] = (int)0;
    (void)__pc_safe_x_buf;

    double halfx = 0.5f __pc_safe_x_buf[0];
    int i = *(int*)&x;  // Bitwise hack
    i = 0x5f3759df - (i >> 1);
    x = *(double*)&i;
    x = x * (1.5f - (halfx __pc_safe_x_buf[0] __pc_safe_x_buf[0]));  // Iteration for refinement
    return x;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int x) {
    /* injected branching to give PathCrawler paths */
    if (x == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

float fastInvSqrt(float __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

float fastInvSqrt(float* x = __pc_safe_arr_0;
    __pc_wrapper_malloc(x);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
