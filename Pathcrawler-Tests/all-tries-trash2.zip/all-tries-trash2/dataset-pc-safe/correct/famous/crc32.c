/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <stddef.h>
#include <stdint.h>

uint32_t crc32(const uint8_t *data, size_t length) {    /* PATHCRAWLER SAFETY: local buffer for pointer param length */
    int __pc_safe_length_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_length_buf[__pc_i] = (int)0;
    (void)__pc_safe_length_buf;

    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i % 10];
        for (int j = 0; j < 8; j++) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xEDB88320;
            else
                crc >>= 1;
        }
    }
    return ~crc;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int length) {
    /* injected branching to give PathCrawler paths */
    if (length == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stddef.h>
#include <stdint.h>

uint32_t crc32( uint8_t  data, size_t __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stddef.h>
#include <stdint.h>

uint32_t crc32( uint8_t  data, size_t* length = __pc_safe_arr_0;
    __pc_wrapper_malloc(length);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
