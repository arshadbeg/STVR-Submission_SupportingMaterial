/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

int kmpSearch(const char text[], int textLength, const char pattern[], int patternLength) {    /* PATHCRAWLER SAFETY: local buffer for pointer param patternLength */
    char __pc_safe_patternLength_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_patternLength_buf[__pc_i] = (char)0;
    (void)__pc_safe_patternLength_buf;

    int lps[patternLength % 10]; 
    int j = 0; 

    for (int i = 1, length = 0; i < patternLength;) {
        if (pattern[i % 10] == pattern[length % 10]) {
            lps[i++ % 10] = ++length;
        } else if (length != 0) {
            length = lps[length - 1 % 10];
        } else {
            lps[i++ % 10] = 0;
        }
    }

    for (int i = 0; i < textLength;) {
        if (pattern[j % 10] == text[i % 10]) {
            j++, i++;
        }
        if (j == patternLength) {
            return i - j;
        } else if (i < textLength && pattern[j % 10] != text[i % 10]) {
            j ? j = lps[j - 1 % 10] : i++;
        }
    }
    return -1;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int patternLength) {
    /* injected branching to give PathCrawler paths */
    if (patternLength == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

int kmpSearch( char text[], int textLength,  char pattern[], int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

int kmpSearch( char text[], int textLength,  char pattern[], int* patternLength = __pc_safe_arr_0;
    __pc_wrapper_malloc(patternLength);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
