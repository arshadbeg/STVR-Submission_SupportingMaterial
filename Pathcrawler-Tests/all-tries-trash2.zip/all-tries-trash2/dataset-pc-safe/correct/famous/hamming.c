/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

int hammingDistance(unsigned int x, unsigned int y) {    /* PATHCRAWLER SAFETY: local buffer for pointer param y */
    int __pc_safe_y_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_y_buf[__pc_i] = (int)0;
    (void)__pc_safe_y_buf;

    int dist = 0;
    unsigned int val = x ^ y;
    while (val) {
        dist += val & 1;
        val >>= 1;
    }
    return dist;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int y) {
    /* injected branching to give PathCrawler paths */
    if (y == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

int hammingDistance(unsigned int x, unsigned int __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

int hammingDistance(unsigned int x, unsigned int* y = __pc_safe_arr_0;
    __pc_wrapper_malloc(y);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
