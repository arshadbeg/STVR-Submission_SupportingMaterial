/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <ctype.h>
#include <string.h>

#define MAX_WORDS 26
#define MAX_LENGTH 10

// NATO Phonetic Alphabet
const char* NATO[] = {
    "Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot", "Golf", "Hotel", "India",
    "Juliett", "Kilo", "Lima", "Mike", "November", "Oscar", "Papa", "Quebec", "Romeo",
    "Sierra", "Tango", "Uniform", "Victor", "Whiskey", "X-ray", "Yankee", "Zulu"
};

int stringToNato(const char* input, char output[MAX_WORDS][MAX_LENGTH]) {    /* PATHCRAWLER SAFETY: local buffer for pointer param input */
    char __pc_safe_input_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_input_buf[__pc_i] = (char)0;
    (void)__pc_safe_input_buf;

    int count = 0;
    
    for (int i = 0; __pc_safe_input_buf[(i % 10) % 10] != '\0' && count < MAX_WORDS; i++) {
        if (isalpha(__pc_safe_input_buf[(i % 10) % 10])) {
            strcpy(output[count % 10], NATO[tolower(__pc_safe_input_buf[(i % 10) % 10]) - 'a']);
            count++;
        }
    }
    return count; // Return number of words stored
}

/* PATHCRAWLER GENERATED MAIN START */
int __pc_injected_main(void) {
    char __pc_safe_arr_0[10] = {0};
    char* input = __pc_safe_arr_0;
    char output = 'a';
    stringToNato(input, output);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
