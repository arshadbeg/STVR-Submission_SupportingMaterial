/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <stdio.h>
#include <stdlib.h>

/* Define the linked list node */
typedef struct Node {
    int digit; // between 0-9
    struct Node* next;
} Node;

// Assume each node contains a single digit number
int concatenateDigits(Node* head) {    /* PATHCRAWLER SAFETY: local buffer for pointer param head */
    int __pc_safe_head_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_head_buf[__pc_i] = (int)0;
    (void)__pc_safe_head_buf;

    int num = 0;
    while (head != NULL) {
        num = num * 10 + __pc_safe_head_buf[0];
        head = __pc_safe_head_buf[0];
    }
    return num;
}

/* PATHCRAWLER GENERATED MAIN START */
int __pc_injected_main(void) {
    Node __pc_safe_arr_0[10] = {0};
    Node* head = __pc_safe_arr_0;
    concatenateDigits(head);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
