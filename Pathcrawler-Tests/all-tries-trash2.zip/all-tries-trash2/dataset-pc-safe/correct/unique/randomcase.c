/* PATHCRAWLER_SANITIZED_HEADER */
#include <stddef.h>
static char __pc_global_buf[16384];
#define malloc(x) ((void*)__pc_global_buf)
#define calloc(n,s) ((void*)__pc_global_buf)
#define realloc(p,s) ((void*)__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /* removed */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

void randomCase(char* str) {    /* PATHCRAWLER SAFETY: local buffer for pointer param str */
    char __pc_safe_str_buf[10];
    for (int __pc_i=0; __pc_i<10; ++__pc_i) __pc_safe_str_buf[__pc_i] = (char)0;
    (void)__pc_safe_str_buf;

    srand(time(NULL)); // Seed RNG

    for (int i = 0; __pc_safe_str_buf[(i % 10) % 10] != '\0'; i++) {
        if (rand() % 2) {
            __pc_safe_str_buf[(i % 10) % 10] = toupper(__pc_safe_str_buf[(i % 10) % 10]);
        } else {
            __pc_safe_str_buf[(i % 10) % 10] = tolower(__pc_safe_str_buf[(i % 10) % 10]);
        }
    }

    return 0;
}

/* PATHCRAWLER GENERATED MAIN START */
/* PATHCRAWLER wrapper generated for unsupported signature of malloc */
void __pc_wrapper_malloc(int str) {
    /* injected branching to give PathCrawler paths */
    if (str == 0) { /* A */ } else { /* B */ }
}


int __pc_injected_main(void) {
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

void randomCase(char __pc_safe_arr_0[10] = {0};
    x) ((void )__pc_global_buf)
#define calloc(n,s) ((void )__pc_global_buf)
#define realloc(p,s) ((void )__pc_global_buf)
#define free(p) ((void)0)
#define __asm__(x) /  removed  /

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

void randomCase(char* str = __pc_safe_arr_0;
    __pc_wrapper_malloc(str);
    return 0;
}

int main(void) { return __pc_injected_main(); }
/* PATHCRAWLER GENERATED MAIN END */
