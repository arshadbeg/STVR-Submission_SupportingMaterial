int max(int a, int b)
{
  int tmp;
  if (a > b) tmp = b; else tmp = a;
  return tmp;
}


