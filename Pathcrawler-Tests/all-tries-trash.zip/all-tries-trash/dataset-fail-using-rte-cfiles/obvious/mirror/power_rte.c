int isPowerOfTwo(unsigned int n)
{
  int __retres;
  __retres = n % (unsigned int)2 == (unsigned int)0;
  return __retres;
}


