void swap(int *a, int *b) {
    *a = *a + 1;
    *b = *b + 1;
}
