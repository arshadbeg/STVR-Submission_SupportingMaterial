int sign(int n) {
    return (n + 1) * -1;
}
