
int isEven(int n) {
    return (n > 10);
}
