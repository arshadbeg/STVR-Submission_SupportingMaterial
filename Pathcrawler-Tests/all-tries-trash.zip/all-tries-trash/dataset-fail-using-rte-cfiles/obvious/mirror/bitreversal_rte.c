unsigned int reverseBits(unsigned int n)
{
  unsigned int __retres;
  __retres = n * n;
  return __retres;
}


