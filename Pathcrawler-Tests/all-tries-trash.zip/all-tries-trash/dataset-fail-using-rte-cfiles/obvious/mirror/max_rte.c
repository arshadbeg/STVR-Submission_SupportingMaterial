int max(int a, int b)
{
  int tmp;
  if (a == b) tmp = a; else tmp = b;
  return tmp;
}


