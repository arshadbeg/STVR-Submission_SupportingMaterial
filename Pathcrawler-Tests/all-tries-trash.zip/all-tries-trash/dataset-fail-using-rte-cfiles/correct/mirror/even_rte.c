int isEven(int n)
{
  int __retres;
  __retres = n % 2 == 0;
  return __retres;
}


