:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(1), while, [cond(atomic_cond(n(3))),body(n(2))]). % reverse.c: l.3
ast_node(n(2), seq, [105,106,107,108,109]). % reverse.c: l.4
ast_node(96, assign, ['start', c(0,i(si(4)))]). % reverse.c: l.2
ast_node(fun(169), func, ['__FC_assert', 4, 0, 0, 91]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(107, assign, [e(+(p(i(si(4))),'arr','end'),c(0,i(si(4)))), 'temp']). % reverse.c: l.6
ast_node(fun(178), func, ['reverseArray', 2, 0, 0, 95]). % reverse.c: l.1
ast_node(105, assign, ['temp', e(+(p(i(si(4))),'arr','start'),c(0,i(si(4))))]). % reverse.c: l.4
ast_node(100, cond, [inf, 'start', 'end']). % reverse.c: l.3
ast_node(95, seq, [96,97,n(1)]). % reverse.c: l.2
ast_node(93, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(111, return, []). % reverse.c: l.10
ast_node(109, assign, ['end', -(i(si(4)),'end',c(1,i(si(4))))]). % reverse.c: l.8
ast_node(106, assign, [e(+(p(i(si(4))),'arr','start'),c(0,i(si(4)))), e(+(p(i(si(4))),'arr','end'),c(0,i(si(4))))]). % reverse.c: l.5
ast_node(97, assign, ['end', -(i(si(4)),'size',c(1,i(si(4))))]). % reverse.c: l.2
ast_node(91, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(108, assign, ['start', +(i(si(4)),'start',c(1,i(si(4))))]). % reverse.c: l.7
atomic_cond(n(3), [empty, 100]).
stmt_location(n(1), 'reverse.c', 3).
stmt_location(n(2), 'reverse.c', 4).
stmt_location(96, 'reverse.c', 2).
stmt_location(fun(169), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(107, 'reverse.c', 6).
stmt_location(fun(178), 'reverse.c', 1).
stmt_location(105, 'reverse.c', 4).
stmt_location(100, 'reverse.c', 3).
stmt_location(95, 'reverse.c', 2).
stmt_location(93, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(111, 'reverse.c', 10).
stmt_location(109, 'reverse.c', 8).
stmt_location(106, 'reverse.c', 5).
stmt_location(97, 'reverse.c', 2).
stmt_location(91, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(108, 'reverse.c', 7).
