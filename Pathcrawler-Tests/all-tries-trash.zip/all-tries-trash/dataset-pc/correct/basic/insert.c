struct Node {
    int data;
    struct Node* next;
};

struct Node* insertAtHead(struct Node* head, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = head;
    return newNode;
}
int main() {
    struct Node head sample_arr[10] = {0};
    int arg2 = 2;
    struct Node* result = insertAtHead(sample_arr, arg2);
    return 0;
}
