:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(5), ite, [cond(atomic_cond(n(8))), then(n(6)), else(empty)]). % strip.c: l.5
ast_node(n(1), while, [cond(atomic_cond(n(3))),body(n(2))]). % strip.c: l.4
ast_node(n(2), seq, [n(5),157]). % strip.c: l.5
ast_node(139, seq, [140,141,n(1),159]). % strip.c: l.3
ast_node(160, return, []). % strip.c: l.11
ast_node(n(7), seq, []). % <unknown location>: l.0
ast_node(153, assign, ['__tmp_lin_0', 'j']). % strip.c: l.6
ast_node(141, assign, ['j', c(0,i(si(4)))]). % strip.c: l.3
ast_node(135, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(164, call, ['stripSpaces', 'sample_str']). % strip.c: l.14
ast_node(157, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % strip.c: l.8
ast_node(154, assign, ['j', +(i(si(4)),'j',c(1,i(si(4))))]). % strip.c: l.6
ast_node(149, cond, [diff, cast(i(si(4)),e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))), c(32,i(si(4)))]). % strip.c: l.5
ast_node(fun(181), func, ['stripSpaces', 1, 0, 0, 139]). % strip.c: l.2
ast_node(137, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(144, cond, [diff, e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), 0]). % strip.c: l.4
ast_node(155, assign, [e(+(p(i(si(1))),'str',mod(i(si(4)),'__tmp_lin_0',c(10,i(si(4))))),c(0,i(si(4)))), e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))]). % strip.c: l.6
ast_node(n(6), seq, [153,154,155]). % strip.c: l.6
ast_node(fun(187), func, ['main', 0, 0, 1, 162]). % strip.c: l.12
ast_node(165, assign, ['__retres', c(0,i(si(4)))]). % strip.c: l.15
ast_node(162, seq, [163,164,165,166]). % strip.c: l.13
ast_node(159, assign, [e(+(p(i(si(1))),'str',mod(i(si(4)),'j',c(10,i(si(4))))),c(0,i(si(4)))), cast(i(si(1)),c(0,i(si(4))))]). % strip.c: l.10
ast_node(166, return, ['__retres']). % strip.c: l.15
ast_node(140, assign, ['i', c(0,i(si(4)))]). % strip.c: l.3
ast_node(fun(172), func, ['__FC_assert', 4, 0, 0, 135]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(i(2), assign, [e('sample_str',c(1,i(si(4)))), cast(i(si(1)),c(98,i(si(4))))]). % strip.c: l.13
ast_node(163, seq, [i(1),i(2),i(3),i(4),i(5),i(6)]). % strip.c: l.13
ast_node(i(6), assign, [e('sample_str',c(5,i(si(4)))), cast(i(si(1)),c(0,i(si(4))))]). % strip.c: l.13
ast_node(i(3), assign, [e('sample_str',c(2,i(si(4)))), cast(i(si(1)),c(99,i(si(4))))]). % strip.c: l.13
ast_node(i(5), assign, [e('sample_str',c(4,i(si(4)))), cast(i(si(1)),c(101,i(si(4))))]). % strip.c: l.13
ast_node(i(4), assign, [e('sample_str',c(3,i(si(4)))), cast(i(si(1)),c(100,i(si(4))))]). % strip.c: l.13
ast_node(i(1), assign, [e('sample_str',c(0,i(si(4)))), cast(i(si(1)),c(97,i(si(4))))]). % strip.c: l.13
atomic_cond(n(8), [empty, 149]).
atomic_cond(n(3), [empty, 144]).
stmt_location(n(5), 'strip.c', 5).
stmt_location(n(1), 'strip.c', 4).
stmt_location(n(2), 'strip.c', 5).
stmt_location(139, 'strip.c', 3).
stmt_location(160, 'strip.c', 11).
stmt_location(n(7), '<unknown location>', 0).
stmt_location(153, 'strip.c', 6).
stmt_location(141, 'strip.c', 3).
stmt_location(135, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(164, 'strip.c', 14).
stmt_location(157, 'strip.c', 8).
stmt_location(154, 'strip.c', 6).
stmt_location(149, 'strip.c', 5).
stmt_location(fun(181), 'strip.c', 2).
stmt_location(137, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(144, 'strip.c', 4).
stmt_location(155, 'strip.c', 6).
stmt_location(n(6), 'strip.c', 6).
stmt_location(fun(187), 'strip.c', 12).
stmt_location(165, 'strip.c', 15).
stmt_location(162, 'strip.c', 13).
stmt_location(159, 'strip.c', 10).
stmt_location(166, 'strip.c', 15).
stmt_location(140, 'strip.c', 3).
stmt_location(fun(172), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(i(2), 'strip.c', 13).
stmt_location(163, 'strip.c', 13).
stmt_location(i(6), 'strip.c', 13).
stmt_location(i(3), 'strip.c', 13).
stmt_location(i(5), 'strip.c', 13).
stmt_location(i(4), 'strip.c', 13).
stmt_location(i(1), 'strip.c', 13).
