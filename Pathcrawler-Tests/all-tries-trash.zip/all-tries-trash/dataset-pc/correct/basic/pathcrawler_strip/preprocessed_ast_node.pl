:- module(ast_node).
:- export ast_node/3.
:- export ast_supernode/4.
:- export topleveldec/3.
:- export ltest_start_branch/2.
:- export ltest_end_branch/2.
:- export immediate_dom_branch_loop_iter/4.
:- export recursive_func/1.
:- export neg_immediate_dom_branch_recur_call/3.
:- export syntactically_inconsistent_branches_mcdc_path/3.
:- export dec_path_and_coverage/3.
:- export syntactically_infeasible_dec_path_and_coverage/5.
:- export syntactically_unreachable_cond_node/1.
:- export syntactically_unreachable_uncond_node/1.
:- export stmt_location/4.
ast_node(n(2), seq, [n(5), 157]).
ast_node(139, seq, [140, 141, n(1), 159]).
ast_node(153, assign, ['__tmp_lin_0', j]).
ast_node(141, assign, [j, c(0, i(si(4)))]).
ast_node(164, call, [stripSpaces, sample_str]).
ast_node(157, assign, [i, +(i(si(4)), i, c(1, i(si(4))))]).
ast_node(154, assign, [j, +(i(si(4)), j, c(1, i(si(4))))]).
ast_node(149, cond, [diff, cast(i(si(4)), e(+(p(i(si(1))), str, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4))))), c(32, i(si(4)))]).
ast_node(fun(181), func, [stripSpaces, 1, 0, 0, 139]).
ast_node(144, cond, [diff, e(+(p(i(si(1))), str, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4)))), 0]).
ast_node(155, assign, [e(+(p(i(si(1))), str, mod(i(si(4)), '__tmp_lin_0', c(10, i(si(4))))), c(0, i(si(4)))), e(+(p(i(si(1))), str, mod(i(si(4)), i, c(10, i(si(4))))), c(0, i(si(4))))]).
ast_node(n(6), seq, [153, 154, 155]).
ast_node(fun(187), func, [main, 0, 0, 1, 162]).
ast_node(159, assign, [e(+(p(i(si(1))), str, mod(i(si(4)), j, c(10, i(si(4))))), c(0, i(si(4)))), cast(i(si(1)), c(0, i(si(4))))]).
ast_node(140, assign, [i, c(0, i(si(4)))]).
ast_node(i(2), assign, [e(sample_str, c(1, i(si(4)))), cast(i(si(1)), c(98, i(si(4))))]).
ast_node(163, seq, [i(1), i(2), i(3), i(4), i(5), i(6)]).
ast_node(i(6), assign, [e(sample_str, c(5, i(si(4)))), cast(i(si(1)), c(0, i(si(4))))]).
ast_node(i(3), assign, [e(sample_str, c(2, i(si(4)))), cast(i(si(1)), c(99, i(si(4))))]).
ast_node(i(5), assign, [e(sample_str, c(4, i(si(4)))), cast(i(si(1)), c(101, i(si(4))))]).
ast_node(i(4), assign, [e(sample_str, c(3, i(si(4)))), cast(i(si(1)), c(100, i(si(4))))]).
ast_node(i(1), assign, [e(sample_str, c(0, i(si(4)))), cast(i(si(1)), c(97, i(si(4))))]).
ast_node(n(5), ite, [149, n(6), empty]).
ast_node(n(1), while, [144, n(2)]).
ast_node(165, setres, [c(0, i(si(4)))]).
ast_node(fun(172), func, ['__FC_assert', 4, 0, 0, empty]).
ast_node(162, seq, [163, 164, 165]).
ast_supernode(139, fun(181), 0, fun(181)).
ast_supernode(162, fun(187), 0, fun(187)).
ast_supernode(163, 162, 0, fun(187)).
ast_supernode(164, 162, 1, fun(187)).
ast_supernode(165, 162, 2, fun(187)).
ast_supernode(i(1), 163, 0, fun(187)).
ast_supernode(i(2), 163, 1, fun(187)).
ast_supernode(i(3), 163, 2, fun(187)).
ast_supernode(i(4), 163, 3, fun(187)).
ast_supernode(i(5), 163, 4, fun(187)).
ast_supernode(i(6), 163, 5, fun(187)).
ast_supernode(n(1), 139, 2, fun(181)).
ast_supernode(n(2), n(1), body, fun(181)).
ast_supernode(n(5), n(2), 0, fun(181)).
ast_supernode(n(6), n(5), then, fun(181)).
ast_supernode(154, n(6), 1, fun(181)).
ast_supernode(153, n(6), 0, fun(181)).
ast_supernode(155, n(6), 2, fun(181)).
ast_supernode(140, 139, 0, fun(181)).
ast_supernode(141, 139, 1, fun(181)).
ast_supernode(157, n(2), 1, fun(181)).
ast_supernode(159, 139, 3, fun(181)).
ast_supernode(149, n(5), cond, fun(181)).
ast_supernode(144, n(1), cond, fun(181)).
topleveldec(149, n(5), [149]).
topleveldec(144, n(1), [144]).
ltest_start_branch(0, 0).
ltest_end_branch(0, 0).
immediate_dom_branch_loop_iter(144, 1, 0, n(1)).
recursive_func(0).
neg_immediate_dom_branch_recur_call(0, 0, 0).
syntactically_inconsistent_branches_mcdc_path(0, 0, 0).
dec_path_and_coverage(0, 0, 0).
syntactically_infeasible_dec_path_and_coverage(0, 0, 0, 0, 0).
syntactically_unreachable_cond_node(0).
syntactically_unreachable_uncond_node(0).
stmt_location(n(5), 'strip.c', 5, 0).
stmt_location(n(1), 'strip.c', 4, 0).
stmt_location(n(2), 'strip.c', 5, 0).
stmt_location(139, 'strip.c', 3, 0).
stmt_location(164, 'strip.c', 14, 0).
stmt_location(157, 'strip.c', 8, 0).
stmt_location(153, 'strip.c', 6, 1).
stmt_location(154, 'strip.c', 6, 2).
stmt_location(149, 'strip.c', 5, 0).
stmt_location(fun(181), 'strip.c', 2, 0).
stmt_location(144, 'strip.c', 4, 0).
stmt_location(155, 'strip.c', 6, 3).
stmt_location(n(6), 'strip.c', 6, 0).
stmt_location(fun(187), 'strip.c', 12, 0).
stmt_location(165, 'strip.c', 15, 0).
stmt_location(159, 'strip.c', 10, 0).
stmt_location(140, 'strip.c', 3, 1).
stmt_location(141, 'strip.c', 3, 2).
stmt_location(fun(172), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79, 0).
stmt_location(162, 'strip.c', 13, 1).
stmt_location(163, 'strip.c', 13, 2).
stmt_location(i(1), 'strip.c', 13, 1).
stmt_location(i(2), 'strip.c', 13, 2).
stmt_location(i(3), 'strip.c', 13, 3).
stmt_location(i(4), 'strip.c', 13, 4).
stmt_location(i(5), 'strip.c', 13, 5).
stmt_location(i(6), 'strip.c', 13, 6).
