:- module(ast_node).

:- export ast_node/3.
:- export atomic_cond/2.
:- export stmt_location/3.

ast_node(n(8), land, [l_op(atomic_cond(n(11))),r_op(atomic_cond(n(9)))]). % lower.c: l.4
ast_node(n(1), for, [cond(atomic_cond(n(4))),body(n(2)),action(n(3))]). % lower.c: l.3
ast_node(n(6), ite, [cond(n(8)), then(n(7)), else(empty)]). % lower.c: l.4
ast_node(n(2), seq, [n(6)]). % lower.c: l.4
ast_node(147, assign, [e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4)))), cast(i(si(1)),+(i(si(4)),cast(i(si(4)),e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))),c(32,i(si(4)))))]). % lower.c: l.5
ast_node(127, seq, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.83
ast_node(152, seq, [153,154,155,156]). % lower.c: l.10
ast_node(n(7), seq, [147]). % lower.c: l.5
ast_node(fun(168), func, ['__FC_assert', 4, 0, 0, 127]). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.79
ast_node(135, cond, [diff, cast(i(si(4)),e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))), c(0,i(si(4)))]). % lower.c: l.3
ast_node(fun(177), func, ['toLowerCase', 1, 0, 0, 131]). % lower.c: l.2
ast_node(154, call, ['toLowerCase', 'sample_str']). % lower.c: l.11
ast_node(fun(181), func, ['main', 0, 0, 1, 152]). % lower.c: l.9
ast_node(156, return, ['__retres']). % lower.c: l.12
ast_node(144, cond, [infegal, cast(i(si(4)),e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))), c(90,i(si(4)))]). % lower.c: l.4
ast_node(155, assign, ['__retres', c(0,i(si(4)))]). % lower.c: l.12
ast_node(131, seq, [132,n(1)]). % lower.c: l.3
ast_node(150, return, []). % lower.c: l.8
ast_node(n(3), seq, [148]). % lower.c: l.3
ast_node(132, assign, ['i', c(0,i(si(4)))]). % lower.c: l.3
ast_node(148, assign, ['i', +(i(si(4)),'i',c(1,i(si(4))))]). % lower.c: l.3
ast_node(140, cond, [supegal, cast(i(si(4)),e(+(p(i(si(1))),'str',mod(i(si(4)),'i',c(10,i(si(4))))),c(0,i(si(4))))), c(65,i(si(4)))]). % lower.c: l.4
ast_node(129, return, []). % FRAMAC_SHARE/pc/lib/lanceur_deb.h: l.85
ast_node(i(2), assign, [e('sample_str',c(1,i(si(4)))), cast(i(si(1)),c(98,i(si(4))))]). % lower.c: l.10
ast_node(153, seq, [i(1),i(2),i(3),i(4),i(5),i(6)]). % lower.c: l.10
ast_node(i(6), assign, [e('sample_str',c(5,i(si(4)))), cast(i(si(1)),c(0,i(si(4))))]). % lower.c: l.10
ast_node(i(3), assign, [e('sample_str',c(2,i(si(4)))), cast(i(si(1)),c(99,i(si(4))))]). % lower.c: l.10
ast_node(i(5), assign, [e('sample_str',c(4,i(si(4)))), cast(i(si(1)),c(101,i(si(4))))]). % lower.c: l.10
ast_node(i(4), assign, [e('sample_str',c(3,i(si(4)))), cast(i(si(1)),c(100,i(si(4))))]). % lower.c: l.10
ast_node(i(1), assign, [e('sample_str',c(0,i(si(4)))), cast(i(si(1)),c(97,i(si(4))))]). % lower.c: l.10
atomic_cond(n(9), [empty, 144]).
atomic_cond(n(11), [empty, 140]).
atomic_cond(n(4), [empty, 135]).
stmt_location(n(8), 'lower.c', 4).
stmt_location(n(1), 'lower.c', 3).
stmt_location(n(6), 'lower.c', 4).
stmt_location(n(2), 'lower.c', 4).
stmt_location(147, 'lower.c', 5).
stmt_location(127, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 83).
stmt_location(152, 'lower.c', 10).
stmt_location(n(7), 'lower.c', 5).
stmt_location(fun(168), 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 79).
stmt_location(135, 'lower.c', 3).
stmt_location(fun(177), 'lower.c', 2).
stmt_location(154, 'lower.c', 11).
stmt_location(fun(181), 'lower.c', 9).
stmt_location(156, 'lower.c', 12).
stmt_location(144, 'lower.c', 4).
stmt_location(155, 'lower.c', 12).
stmt_location(131, 'lower.c', 3).
stmt_location(150, 'lower.c', 8).
stmt_location(n(3), 'lower.c', 3).
stmt_location(132, 'lower.c', 3).
stmt_location(148, 'lower.c', 3).
stmt_location(140, 'lower.c', 4).
stmt_location(129, 'FRAMAC_SHARE/pc/lib/lanceur_deb.h', 85).
stmt_location(i(2), 'lower.c', 10).
stmt_location(153, 'lower.c', 10).
stmt_location(i(6), 'lower.c', 10).
stmt_location(i(3), 'lower.c', 10).
stmt_location(i(5), 'lower.c', 10).
stmt_location(i(4), 'lower.c', 10).
stmt_location(i(1), 'lower.c', 10).
