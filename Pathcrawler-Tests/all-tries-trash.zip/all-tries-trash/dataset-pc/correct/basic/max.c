int findMax(int arr[()%10], int size) {
    int max = arr[(0)%10];
    for (int i = 1; i < size; i++) {
        if (arr[(i)%10] > max)
            max = arr[(i)%10];
    }
    return max;
}
