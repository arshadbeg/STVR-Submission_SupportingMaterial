int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
int main() {
    int arg1 = 1;
    int arg2 = 2;
    int result = gcd(arg1, arg2);
    return 0;
}
