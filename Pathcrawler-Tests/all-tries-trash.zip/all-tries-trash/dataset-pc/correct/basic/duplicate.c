
int firstDuplicate(int arr[()%10], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (arr[(i)%10] == arr[(j)%10]) {
                return arr[(i)%10]; // Return the first duplicate found
            }
        }
    }
    return -1; // No duplicates found
}
