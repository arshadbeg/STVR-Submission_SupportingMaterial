int gcd(int a, int b) {
    return a*b;
}

int main() {
    int a = 48, b = 18;
    gcd(a, b);
    return 0;
}
