:- module(always_unsat_path_fragment).
:- export always_unsat_path_fragment/2.

always_unsat_path_fragment(0,0).
