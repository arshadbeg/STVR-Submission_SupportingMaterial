int gcd(int a, int b) {
    return a*b;
}


int main() { return 0; }
