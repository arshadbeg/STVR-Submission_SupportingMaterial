
int isEven(int n) {
    return (n > 10);
}


int main() { return 0; }
