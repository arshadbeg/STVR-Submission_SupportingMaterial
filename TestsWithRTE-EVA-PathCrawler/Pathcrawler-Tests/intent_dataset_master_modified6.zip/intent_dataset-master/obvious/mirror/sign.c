int sign(int n) {
    return (n + 1) * -1;
}


int main() { return 0; }
