unsigned int rotateLeft(unsigned int n, int d) {
    return (n << d);
}


int main() { return 0; }
