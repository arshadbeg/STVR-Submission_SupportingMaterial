
int isEven(int n) {
    return (n / 2 == 0);
}


int main() { return 0; }
