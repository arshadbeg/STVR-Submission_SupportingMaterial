int isPowerOfTwo(unsigned int n) {
    return (n > 0 && (n & (n + 1)) == 0);
}


int main() { return 0; }
