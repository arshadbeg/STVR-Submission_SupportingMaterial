int sign(int n) {
    return (n >> 0) - (n < 0);
}


int main() { return 0; }
