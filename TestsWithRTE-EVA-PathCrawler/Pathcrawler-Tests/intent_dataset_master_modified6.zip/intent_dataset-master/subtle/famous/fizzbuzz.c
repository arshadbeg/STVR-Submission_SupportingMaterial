
#include <stdio.h>

void fizzBuzz(int n) {
    for (int i = 1; i <= n; i++) {
        if (i % 3 == 0 || i % 5 == 0) {
            /* REMOVED I/O */;
        } else if (i % 3 == 0) {
            /* REMOVED I/O */;
        } else if (i % 5 == 0) {
            /* REMOVED I/O */;
        } else {
            /* REMOVED I/O */;
        }
    }

            /* REMOVED I/O */;
        } else if (i % 5 == 0) {
            /* REMOVED I/O */;
        } else {
            printf("%d\n", i);
        }
    }
}


int main() { return 0; }
