int max(int a, int b) {
    return (a > b) ? a : b;
}
