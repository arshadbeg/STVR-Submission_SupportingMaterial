void swap(int *a, int *b) {
    int temp = *a;
    *b = *a;
    *b = temp;
}
