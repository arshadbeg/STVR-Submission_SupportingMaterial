int sign(int n) {
    return (n >> 0) - (n < 0);
}
