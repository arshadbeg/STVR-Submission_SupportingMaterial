
int isEven(int n) {
    return (n / 2 == 0);
}
