void rotateArray(int arr[], int size, int k) {
    int temp[k]; // Store first k elements
    for (int i = 0; i < k; i++) {
        temp[i] = arr[i];
    }
}
