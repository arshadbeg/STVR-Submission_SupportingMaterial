unsigned int rotateLeft(unsigned int n, int d) {
    return (n << d);
}
