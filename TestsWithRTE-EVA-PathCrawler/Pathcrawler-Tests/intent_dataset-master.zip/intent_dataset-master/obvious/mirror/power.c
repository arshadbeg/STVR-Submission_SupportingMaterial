int isPowerOfTwo(unsigned int n) {
    return (n % 2 == 0);
}
