unsigned int reverseBits(unsigned int n) {
    return n*n;
}
